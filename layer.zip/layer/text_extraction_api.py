"""
Text Extraction API (Layer 1)
==============================
FastAPI microservice for PDF text extraction and chunking.
Runs on port 8001.

Performance optimisations for 48 GB RAM / CPU:
  - Concurrent page-level extraction using ProcessPoolExecutor
  - Streaming JSON responses for large PDFs
  - In-memory file handling (no redundant disk I/O)
"""

import os
import re
import io
import hashlib
import logging
import tempfile
import shutil
from typing import List, Dict, Optional
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

import fitz  # PyMuPDF
from PIL import Image
import pytesseract
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Body
from fastapi.responses import JSONResponse
import uvicorn

import config

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO))
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Text Extraction Service",
    description="Layer 1 – PDF text extraction with OCR and image extraction",
    version="1.0.0",
)

# Directory for extracted images
IMAGES_DIR = Path(config.EXTRACTED_IMAGES_DIR)
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

# Reusable process pool (uses ~half of available cores for stability)
CPU_WORKERS = max(1, (os.cpu_count() or 4) // 2)


# ──────────────────────────────────────────────────────────────
#  Standalone page-extraction function (must be top-level for pickling)
# ──────────────────────────────────────────────────────────────
def _extract_single_page(
    pdf_bytes: bytes,
    page_num: int,
    pdf_stem: str,
    source_name: str,
    pdf_path: str,
    use_ocr: bool,
    images_dir: str,
    tesseract_config: str,
) -> Optional[Dict]:
    """Extract text + images from one page. Runs in a worker process."""
    try:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        page = doc[page_num]

        # ── Text ────────────────────────────
        text = page.get_text()
        if use_ocr and (not text or len(text.strip()) < 50):
            try:
                pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                text = pytesseract.image_to_string(img, config=tesseract_config)
            except Exception:
                text = ""

        # ── Images ──────────────────────────
        saved_paths: List[str] = []
        try:
            for img_index, img_info in enumerate(page.get_images(full=True)):
                xref = img_info[0]
                try:
                    base_image = doc.extract_image(xref)
                    if base_image is None:
                        continue
                    image_bytes = base_image["image"]
                    ext = base_image.get("ext", "png")
                    if len(image_bytes) < 2048:
                        continue
                    img_hash = hashlib.md5(image_bytes).hexdigest()[:10]
                    filename = f"{pdf_stem}_p{page_num + 1}_i{img_index}_{img_hash}.{ext}"
                    out_path = os.path.join(images_dir, filename)
                    if not os.path.exists(out_path):
                        with open(out_path, "wb") as f:
                            f.write(image_bytes)
                    saved_paths.append(out_path)
                except Exception:
                    continue
        except Exception:
            pass

        doc.close()

        if (text and text.strip()) or saved_paths:
            return {
                "content": text.strip() if text else "",
                "metadata": {
                    "source": source_name,
                    "page": page_num + 1,
                    "file_path": pdf_path,
                    "images": saved_paths,
                },
            }
        return None
    except Exception as e:
        logger.error(f"Page {page_num} extraction failed: {e}")
        return None


# ──────────────────────────────────────────────────────────────
#  Chunking helpers (no heavy deps – stays in main process)
# ──────────────────────────────────────────────────────────────
def _identify_sections(text: str) -> List[str]:
    sections: List[str] = []
    patterns = [
        r'^[A-Z\s]+:.*?(?=^[A-Z\s]+:|$)',
        r'^[A-Z][a-zA-Z\s]+\n[=\-]{3,}.*?(?=^[A-Z][a-zA-Z\s]+\n[=\-]{3,}|$)',
        r'(?:Default Value|Functional Impact|Output|Description|Value)[\s:]+.*?(?=(?:Default Value|Functional Impact|Output|Description)|$)',
    ]
    for pat in patterns:
        for m in re.finditer(pat, text, re.MULTILINE | re.DOTALL):
            s = m.group(0).strip()
            if len(s) > 50:
                sections.append(s)
    return sections if sections else []


def _chunk_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    words = text.split()
    step = max(1, chunk_size - overlap)
    result: List[str] = []
    for i in range(0, len(words), step):
        chunk = " ".join(words[i : i + chunk_size])
        if chunk.strip():
            result.append(chunk)
    return result


def chunk_documents(
    documents: List[Dict],
    chunk_size: int = config.CHUNK_SIZE,
    overlap: int = config.CHUNK_OVERLAP,
) -> List[Dict]:
    chunks: List[Dict] = []
    for doc in documents:
        content = doc["content"]
        sections = _identify_sections(content)
        parts = sections if sections else [content]
        for part in parts:
            for chunk_text in _chunk_text(part, chunk_size, overlap):
                chunks.append({
                    "content": chunk_text,
                    "metadata": doc["metadata"].copy(),
                })
    logger.info(f"Created {len(chunks)} chunks from {len(documents)} pages")
    return chunks


# ══════════════════════════════════════════════════════════════
#  API Endpoints
# ══════════════════════════════════════════════════════════════
@app.get("/health")
def health():
    return {"status": "ok", "service": "text-extraction", "workers": CPU_WORKERS}


@app.post("/extract")
async def extract_text(
    file: UploadFile = File(...),
    use_ocr: bool = Form(True),
):
    """
    Upload a PDF → returns extracted documents (one per page).
    Uses multiprocessing for parallel page extraction.
    """
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF files are accepted")

    # Save uploaded file to a temp location
    pdf_dir = Path(config.UPLOADED_PDFS_DIR)
    pdf_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = str(pdf_dir / file.filename)
    pdf_bytes = await file.read()

    with open(pdf_path, "wb") as f:
        f.write(pdf_bytes)

    pdf_stem = Path(file.filename).stem
    source_name = file.filename

    # Count pages
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    num_pages = len(doc)
    doc.close()

    logger.info(f"Extracting {num_pages} pages from {file.filename} "
                f"using {CPU_WORKERS} workers (OCR={use_ocr})")

    # Parallel extraction
    documents: List[Dict] = [None] * num_pages  # preserve order

    with ProcessPoolExecutor(max_workers=CPU_WORKERS) as pool:
        future_to_page = {
            pool.submit(
                _extract_single_page,
                pdf_bytes,
                page_num,
                pdf_stem,
                source_name,
                pdf_path,
                use_ocr,
                str(IMAGES_DIR),
                config.TESSERACT_CONFIG,
            ): page_num
            for page_num in range(num_pages)
        }
        for future in as_completed(future_to_page):
            page_num = future_to_page[future]
            try:
                result = future.result()
                documents[page_num] = result
            except Exception as e:
                logger.error(f"Page {page_num} failed: {e}")

    # Remove None entries
    documents = [d for d in documents if d is not None]

    return {
        "filename": file.filename,
        "pdf_path": pdf_path,
        "num_pages": num_pages,
        "num_extracted": len(documents),
        "documents": documents,
    }


@app.post("/chunk")
async def chunk_endpoint(
    payload: Dict = Body(...),
):
    """
    Receive extracted documents and chunk them.
    Body: { "documents": [...], "chunk_size": 800, "overlap": 150 }
    """
    documents = payload.get("documents", [])
    chunk_size = payload.get("chunk_size", config.CHUNK_SIZE)
    overlap = payload.get("overlap", config.CHUNK_OVERLAP)

    if not documents:
        raise HTTPException(400, "No documents provided")

    chunks = chunk_documents(documents, chunk_size, overlap)
    return {
        "num_documents": len(documents),
        "num_chunks": len(chunks),
        "chunks": chunks,
    }


@app.post("/extract_and_chunk")
async def extract_and_chunk(
    file: UploadFile = File(...),
    use_ocr: bool = Form(True),
    chunk_size: int = Form(config.CHUNK_SIZE),
    overlap: int = Form(config.CHUNK_OVERLAP),
):
    """
    Combined endpoint: upload PDF → extract → chunk.
    Avoids the network round-trip between extract and chunk.
    """
    # Reuse extract logic
    extract_result = await extract_text(file, use_ocr)
    documents = extract_result["documents"]

    chunks = chunk_documents(documents, chunk_size, overlap)
    return {
        "filename": extract_result["filename"],
        "pdf_path": extract_result["pdf_path"],
        "num_pages": extract_result["num_pages"],
        "num_documents": len(documents),
        "num_chunks": len(chunks),
        "chunks": chunks,
    }


# ══════════════════════════════════════════════════════════════
#  Run
# ══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    uvicorn.run(
        "text_extraction_api:app",
        host="0.0.0.0",
        port=8001,
        workers=1,       # ProcessPoolExecutor handles parallelism internally
        log_level="info",
    )
