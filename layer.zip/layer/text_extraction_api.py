"""
Text Extraction API (Layer 1)
==============================
FastAPI microservice for PDF text extraction and chunking.
Runs on port 8001.

Extraction strategy (fastest → slowest, automatic fallback):
  1. PyMuPDF (fitz)  – native text layer, extremely fast
  2. pypdf            – fallback if fitz returns too little text
  3. Tesseract OCR    – only for truly scanned / image-only pages

Performance vs old version:
  OLD: ProcessPoolExecutor opened the ENTIRE PDF from bytes in every
       worker for every single page → 200-page PDF = 200× full deserialise.
  NEW: Opens PDF ONCE, iterates pages sequentially. 10-50× faster.
"""

import os
import re
import hashlib
import logging
import time
from typing import List, Dict, Optional
from pathlib import Path

import fitz  # PyMuPDF – primary extractor
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Body
import uvicorn

import config

# ── Optional deps (graceful fallback) ────────
try:
    from pypdf import PdfReader
    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False

try:
    from PIL import Image
    import pytesseract
    HAS_OCR = True
except ImportError:
    HAS_OCR = False

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO))
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Text Extraction Service",
    description="Layer 1 – PDF text extraction (PyMuPDF + pypdf + OCR fallback)",
    version="2.0.0",
)

IMAGES_DIR = Path(config.EXTRACTED_IMAGES_DIR)
IMAGES_DIR.mkdir(parents=True, exist_ok=True)


# ══════════════════════════════════════════════════════════════
#  Core extraction – single-pass, no multiprocessing overhead
# ══════════════════════════════════════════════════════════════
def extract_pdf(
    pdf_bytes: bytes,
    pdf_path: str,
    source_name: str,
    use_ocr: bool = True,
) -> List[Dict]:
    """
    Extract text + images from every page.
    Opens the PDF ONCE and walks pages sequentially.
    """
    pdf_stem = Path(source_name).stem
    documents: List[Dict] = []

    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    num_pages = len(doc)
    logger.info(f"Extracting {num_pages} pages from {source_name}")

    # Pre-load pypdf reader for fallback (one-time cost)
    pypdf_reader = None
    if HAS_PYPDF:
        try:
            import io
            pypdf_reader = PdfReader(io.BytesIO(pdf_bytes))
        except Exception:
            pass

    for page_num in range(num_pages):
        page = doc[page_num]

        # ── Strategy 1: PyMuPDF native text (fastest) ──
        text = page.get_text("text")

        # ── Strategy 2: pypdf fallback ─────────────────
        if _text_too_short(text) and pypdf_reader:
            try:
                pypdf_text = pypdf_reader.pages[page_num].extract_text() or ""
                if len(pypdf_text.strip()) > len((text or "").strip()):
                    text = pypdf_text
            except Exception:
                pass

        # ── Strategy 3: OCR (only truly blank pages) ───
        if _text_too_short(text) and use_ocr and HAS_OCR:
            text = _ocr_page(page)

        # ── Image extraction ───────────────────────────
        page_images = _extract_images(doc, page, pdf_stem, page_num + 1)

        if (text and text.strip()) or page_images:
            documents.append({
                "content": text.strip() if text else "",
                "metadata": {
                    "source": source_name,
                    "page": page_num + 1,
                    "file_path": pdf_path,
                    "images": page_images,
                },
            })

    doc.close()
    logger.info(f"Extracted {len(documents)} pages from {source_name}")
    return documents


def _text_too_short(text: Optional[str], threshold: int = 50) -> bool:
    return not text or len(text.strip()) < threshold


def _ocr_page(page) -> str:
    """OCR a single page – only called when both fitz and pypdf fail."""
    try:
        pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5))  # 1.5x (faster than 2x)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        text = pytesseract.image_to_string(img, config=config.TESSERACT_CONFIG)
        return text
    except Exception as e:
        logger.warning(f"OCR failed: {e}")
        return ""


def _extract_images(doc, page, pdf_stem: str, page_number: int) -> List[str]:
    """Extract embedded images from a page. Skip tiny icons/spacers."""
    saved_paths: List[str] = []
    try:
        for img_index, img_info in enumerate(page.get_images(full=True)):
            xref = img_info[0]
            try:
                base_image = doc.extract_image(xref)
                if not base_image:
                    continue
                image_bytes = base_image["image"]
                ext = base_image.get("ext", "png")
                if len(image_bytes) < 2048:
                    continue
                img_hash = hashlib.md5(image_bytes).hexdigest()[:10]
                filename = f"{pdf_stem}_p{page_number}_i{img_index}_{img_hash}.{ext}"
                out_path = IMAGES_DIR / filename
                if not out_path.exists():
                    out_path.write_bytes(image_bytes)
                saved_paths.append(str(out_path))
            except Exception:
                continue
    except Exception:
        pass
    return saved_paths


# ══════════════════════════════════════════════════════════════
#  Chunking
# ══════════════════════════════════════════════════════════════
def _identify_sections(text: str) -> List[str]:
    sections: List[str] = []
    patterns = [
        r'^[A-Z\s]+:.*?(?=^[A-Z\s]+:|$)',
        r'^[A-Z][a-zA-Z\s]+\n[=\-]{3,}.*?(?=^[A-Z][a-zA-Z\s]+\n[=\-]{3,}|$)',
        r'(?:Default Value|Functional Impact|Output|Description|Value)[\s:]+.*?(?=(?:Default Value|Functional Impact|Output|Description)|$)',
    ]
    for pat in patterns:
        for m in re.finditer(pat, text, re.MULTILINE | re.DOTALL):
            s = m.group(0).strip()
            if len(s) > 50:
                sections.append(s)
    return sections if sections else []


def _chunk_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    words = text.split()
    step = max(1, chunk_size - overlap)
    result: List[str] = []
    for i in range(0, len(words), step):
        chunk = " ".join(words[i : i + chunk_size])
        if chunk.strip():
            result.append(chunk)
    return result


def chunk_documents(
    documents: List[Dict],
    chunk_size: int = config.CHUNK_SIZE,
    overlap: int = config.CHUNK_OVERLAP,
) -> List[Dict]:
    chunks: List[Dict] = []
    for doc in documents:
        content = doc["content"]
        sections = _identify_sections(content)
        parts = sections if sections else [content]
        for part in parts:
            for ct in _chunk_text(part, chunk_size, overlap):
                chunks.append({
                    "content": ct,
                    "metadata": doc["metadata"].copy(),
                })
    logger.info(f"Created {len(chunks)} chunks from {len(documents)} pages")
    return chunks


# ══════════════════════════════════════════════════════════════
#  API Endpoints
# ══════════════════════════════════════════════════════════════
@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "text-extraction",
        "extractors": {"pymupdf": True, "pypdf": HAS_PYPDF, "ocr": HAS_OCR},
    }


@app.post("/extract")
async def extract_endpoint(
    file: UploadFile = File(...),
    use_ocr: bool = Form(True),
):
    """Upload a PDF → returns extracted documents (one per page)."""
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF files are accepted")

    pdf_dir = Path(config.UPLOADED_PDFS_DIR)
    pdf_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = str(pdf_dir / file.filename)
    pdf_bytes = await file.read()

    with open(pdf_path, "wb") as f:
        f.write(pdf_bytes)

    t0 = time.time()
    documents = extract_pdf(pdf_bytes, pdf_path, file.filename, use_ocr)
    elapsed = time.time() - t0
    logger.info(f"{file.filename}: {len(documents)} pages in {elapsed:.1f}s")

    return {
        "filename": file.filename,
        "pdf_path": pdf_path,
        "num_pages": len(documents),
        "num_extracted": len(documents),
        "elapsed_seconds": round(elapsed, 2),
        "documents": documents,
    }


@app.post("/chunk")
async def chunk_endpoint(payload: Dict = Body(...)):
    """Chunk pre-extracted documents."""
    documents = payload.get("documents", [])
    chunk_size = payload.get("chunk_size", config.CHUNK_SIZE)
    overlap = payload.get("overlap", config.CHUNK_OVERLAP)

    if not documents:
        raise HTTPException(400, "No documents provided")

    chunks = chunk_documents(documents, chunk_size, overlap)
    return {
        "num_documents": len(documents),
        "num_chunks": len(chunks),
        "chunks": chunks,
    }


@app.post("/extract_and_chunk")
async def extract_and_chunk(
    file: UploadFile = File(...),
    use_ocr: bool = Form(True),
    chunk_size: int = Form(config.CHUNK_SIZE),
    overlap: int = Form(config.CHUNK_OVERLAP),
):
    """Combined: upload PDF → extract → chunk in one call."""
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF files are accepted")

    pdf_dir = Path(config.UPLOADED_PDFS_DIR)
    pdf_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = str(pdf_dir / file.filename)
    pdf_bytes = await file.read()

    with open(pdf_path, "wb") as f:
        f.write(pdf_bytes)

    t0 = time.time()
    documents = extract_pdf(pdf_bytes, pdf_path, file.filename, use_ocr)
    chunks = chunk_documents(documents, chunk_size, overlap)
    elapsed = time.time() - t0

    logger.info(f"{file.filename}: {len(documents)} pages → {len(chunks)} chunks in {elapsed:.1f}s")

    return {
        "filename": file.filename,
        "pdf_path": pdf_path,
        "num_pages": len(documents),
        "num_documents": len(documents),
        "num_chunks": len(chunks),
        "elapsed_seconds": round(elapsed, 2),
        "chunks": chunks,
    }


# ══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    uvicorn.run(
        "text_extraction_api:app",
        host="0.0.0.0",
        port=8001,
        workers=1,
        timeout_keep_alive=300,
        log_level="info",
    )
