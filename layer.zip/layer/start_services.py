"""
Start All Microservices
========================
Launches all 3 API services + Streamlit UI in separate processes.

Usage:
    python start_services.py           # Start all
    python start_services.py --no-ui   # APIs only (no Streamlit)
"""

import subprocess
import sys
import os
import signal
import time
import argparse

SERVICES = [
    {
        "name": "Text Extraction API",
        "cmd": [sys.executable, "text_extraction_api.py"],
        "port": 8001,
    },
    {
        "name": "RAG Service API",
        "cmd": [sys.executable, "rag_api.py"],
        "port": 8002,
    },
    {
        "name": "Chat Orchestrator API",
        "cmd": [sys.executable, "chat_api.py"],
        "port": 8003,
    },
]

UI_SERVICE = {
    "name": "Streamlit UI",
    "cmd": [sys.executable, "-m", "streamlit", "run", "app.py", "--server.port", "8501"],
    "port": 8501,
}


def main():
    parser = argparse.ArgumentParser(description="Start PDF Knowledge Bot microservices")
    parser.add_argument("--no-ui", action="store_true", help="Skip starting Streamlit UI")
    args = parser.parse_args()

    workdir = os.path.dirname(os.path.abspath(__file__))
    processes = []

    def cleanup(signum=None, frame=None):
        print("\n🛑 Shutting down all services …")
        for name, proc in processes:
            try:
                proc.terminate()
                proc.wait(timeout=5)
                print(f"   ✅ {name} stopped")
            except Exception:
                proc.kill()
                print(f"   ⚠️  {name} killed")
        sys.exit(0)

    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    print("=" * 60)
    print("  📚 PDF Knowledge Bot – Microservice Launcher")
    print("=" * 60)

    # Start API services
    for svc in SERVICES:
        print(f"\n🚀 Starting {svc['name']} on port {svc['port']} …")
        proc = subprocess.Popen(
            svc["cmd"],
            cwd=workdir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        processes.append((svc["name"], proc))
        time.sleep(1)  # Small delay between services

    # Wait for RAG service (loads embedding model) to be ready
    print("\n⏳ Waiting for RAG Service to load embedding model …")
    for i in range(120):  # up to 2 minutes
        try:
            import requests
            r = requests.get("http://localhost:8002/health", timeout=2)
            if r.status_code == 200:
                print("   ✅ RAG Service ready!")
                break
        except Exception:
            pass
        time.sleep(1)
    else:
        print("   ⚠️  RAG Service did not respond in time (may still be loading)")

    # Start Streamlit UI
    if not args.no_ui:
        print(f"\n🚀 Starting {UI_SERVICE['name']} on port {UI_SERVICE['port']} …")
        proc = subprocess.Popen(
            UI_SERVICE["cmd"],
            cwd=workdir,
        )
        processes.append((UI_SERVICE["name"], proc))

    print("\n" + "=" * 60)
    print("  ✅ All services started!")
    print("=" * 60)
    print(f"\n  📡 Text Extraction API : http://localhost:8001")
    print(f"  📡 RAG Service API     : http://localhost:8002")
    print(f"  📡 Chat Orchestrator   : http://localhost:8003")
    if not args.no_ui:
        print(f"  🌐 Streamlit UI        : http://localhost:8501")
    print(f"\n  📖 API docs:")
    print(f"     http://localhost:8001/docs   (Text Extraction)")
    print(f"     http://localhost:8002/docs   (RAG Service)")
    print(f"     http://localhost:8003/docs   (Chat Orchestrator)")
    print(f"\n  Press Ctrl+C to stop all services\n")

    # Wait for all processes
    try:
        while True:
            for name, proc in processes:
                if proc.poll() is not None:
                    print(f"⚠️  {name} exited with code {proc.returncode}")
            time.sleep(2)
    except KeyboardInterrupt:
        cleanup()


if __name__ == "__main__":
    main()
