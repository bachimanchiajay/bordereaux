"""
Start Microservices – Independently or All Together
=====================================================
Usage:
    python start_services.py                  # Start ALL services
    python start_services.py --step 1         # Step 1: Text Extraction only (port 8001)
    python start_services.py --step 2         # Step 2: RAG Service only     (port 8002)
    python start_services.py --step 3         # Step 3: Chat Orchestrator    (port 8003)
    python start_services.py --ui             # Streamlit UI only            (port 8501)
    python start_services.py --no-ui          # All APIs, no UI
"""

import subprocess
import sys
import os
import signal
import time
import argparse

SERVICES = {
    1: {
        "name": "Text Extraction API",
        "cmd": [sys.executable, "text_extraction_api.py"],
        "port": 8001,
    },
    2: {
        "name": "RAG Service API",
        "cmd": [sys.executable, "rag_api.py"],
        "port": 8002,
    },
    3: {
        "name": "Chat Orchestrator API",
        "cmd": [sys.executable, "chat_api.py"],
        "port": 8003,
    },
}

UI_SERVICE = {
    "name": "Streamlit UI",
    "cmd": [sys.executable, "-m", "streamlit", "run", "app.py", "--server.port", "8501"],
    "port": 8501,
}


def main():
    parser = argparse.ArgumentParser(
        description="Start PDF Knowledge Bot microservices",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Recommended workflow (run each in a SEPARATE terminal):
  Terminal 1:  python start_services.py --step 1      # Extract PDFs
  Terminal 2:  python start_services.py --step 2      # Index chunks (downloads model first time)
  Terminal 3:  python start_services.py --step 3      # Chat orchestrator
  Terminal 4:  python start_services.py --ui           # Streamlit UI

Or run everything at once:
  python start_services.py
        """,
    )
    parser.add_argument(
        "--step", type=int, choices=[1, 2, 3],
        help="Run a single service: 1=TextExtraction, 2=RAG, 3=Chat",
    )
    parser.add_argument("--ui", action="store_true", help="Start Streamlit UI only")
    parser.add_argument("--no-ui", action="store_true", help="Start all APIs without UI")
    args = parser.parse_args()

    workdir = os.path.dirname(os.path.abspath(__file__))
    processes = []

    def cleanup(signum=None, frame=None):
        print("\n🛑 Shutting down …")
        for name, proc in processes:
            try:
                proc.terminate()
                proc.wait(timeout=5)
                print(f"   ✅ {name} stopped")
            except Exception:
                proc.kill()
                print(f"   ⚠️  {name} killed")
        sys.exit(0)

    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    print("=" * 60)
    print("  📚 PDF Knowledge Bot – Microservice Launcher")
    print("=" * 60)

    # ── Single service mode ──────────────────
    if args.step:
        svc = SERVICES[args.step]
        print(f"\n🚀 Starting {svc['name']} on port {svc['port']} …")
        print(f"   Press Ctrl+C to stop\n")
        # Run in foreground (not piped) so user sees logs
        try:
            proc = subprocess.Popen(svc["cmd"], cwd=workdir)
            processes.append((svc["name"], proc))
            proc.wait()
        except KeyboardInterrupt:
            cleanup()
        return

    # ── UI-only mode ─────────────────────────
    if args.ui:
        print(f"\n🚀 Starting Streamlit UI on port 8501 …")
        print(f"   Open http://localhost:8501 in your browser")
        print(f"   Press Ctrl+C to stop\n")
        try:
            proc = subprocess.Popen(UI_SERVICE["cmd"], cwd=workdir)
            processes.append((UI_SERVICE["name"], proc))
            proc.wait()
        except KeyboardInterrupt:
            cleanup()
        return

    # ── All services mode ────────────────────
    for step_num in [1, 2, 3]:
        svc = SERVICES[step_num]
        print(f"\n🚀 Starting {svc['name']} on port {svc['port']} …")
        proc = subprocess.Popen(
            svc["cmd"],
            cwd=workdir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        processes.append((svc["name"], proc))
        time.sleep(1)

    # Wait for RAG service (loads embedding model)
    print("\n⏳ Waiting for RAG Service to load embedding model …")
    for i in range(180):  # up to 3 minutes
        try:
            import requests
            r = requests.get("http://localhost:8002/health", timeout=2)
            if r.status_code == 200:
                print("   ✅ RAG Service ready!")
                break
        except Exception:
            pass
        time.sleep(1)
    else:
        print("   ⚠️  RAG Service did not respond in time (may still be loading model)")

    if not args.no_ui:
        print(f"\n🚀 Starting Streamlit UI on port 8501 …")
        proc = subprocess.Popen(UI_SERVICE["cmd"], cwd=workdir)
        processes.append((UI_SERVICE["name"], proc))

    print("\n" + "=" * 60)
    print("  ✅ All services started!")
    print("=" * 60)
    print(f"\n  📡 Text Extraction API : http://localhost:8001")
    print(f"  📡 RAG Service API     : http://localhost:8002")
    print(f"  📡 Chat Orchestrator   : http://localhost:8003")
    if not args.no_ui:
        print(f"  🌐 Streamlit UI        : http://localhost:8501")
    print(f"\n  📖 API docs:")
    print(f"     http://localhost:8001/docs   (Text Extraction)")
    print(f"     http://localhost:8002/docs   (RAG Service)")
    print(f"     http://localhost:8003/docs   (Chat Orchestrator)")
    print(f"\n  Press Ctrl+C to stop all services\n")

    try:
        while True:
            for name, proc in processes:
                if proc.poll() is not None:
                    print(f"⚠️  {name} exited with code {proc.returncode}")
            time.sleep(2)
    except KeyboardInterrupt:
        cleanup()


if __name__ == "__main__":
    main()
