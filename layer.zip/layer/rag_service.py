"""
Layer 2 – RAG Service
======================
Nomic Embed v1.5 embeddings  ·  FAISS vector index  ·  TF-IDF keyword search
Knowledge Graph  ·  Hybrid Reciprocal-Rank Fusion retrieval
"""

import os
import re
import pickle
import logging
from typing import List, Dict, Tuple
from collections import defaultdict

import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
from sklearn.feature_extraction.text import TfidfVectorizer
import networkx as nx
from tqdm import tqdm

import config

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO))
logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════
#  Knowledge Graph
# ══════════════════════════════════════════════════════════════
class KnowledgeGraph:
    """Build and query a directed graph of entities extracted from chunks."""

    def __init__(self):
        self.graph = nx.DiGraph()
        self.entities: Dict[str, set] = defaultdict(set)

    # ── build ────────────────────────────────────────────────
    def build_from_chunks(self, chunks: List[Dict]):
        logger.info("Building knowledge graph …")
        for chunk in tqdm(chunks, desc="KG extraction"):
            content = chunk["content"]
            meta = chunk["metadata"]

            # Fields:  ALL-CAPS NAME : description
            field_matches = re.findall(
                r'([A-Z][A-Z\s]{2,})\s*[:=\-]\s*([^\n]+)', content
            )
            for fname, desc in field_matches:
                fname = fname.strip()
                self.graph.add_node(
                    fname,
                    type="field",
                    description=desc.strip(),
                    page=meta["page"],
                    source=meta["source"],
                )
                self.entities["field"].add(fname)

            # Screen names  e.g.  ABCP01
            for screen in re.findall(r'([A-Z][A-Z0-9]+P[0-9]+)', content):
                self.graph.add_node(screen, type="screen")
                self.entities["screen"].add(screen)

            # Value / Code tokens
            for val in re.findall(r'(?:Value|Code)[\s:]+([A-Z0-9]+)', content):
                self.graph.add_node(val, type="value")
                self.entities["value"].add(val)

            # Edges
            screens = re.findall(r'([A-Z][A-Z0-9]+P[0-9]+)', content)
            values  = re.findall(r'(?:Value|Code)[\s:]+([A-Z0-9]+)', content)
            for fname, _ in field_matches:
                fname = fname.strip()
                for s in screens:
                    self.graph.add_edge(fname, s, relation="appears_in")
                for v in values:
                    self.graph.add_edge(fname, v, relation="has_value")

        logger.info(
            f"KG ready: {self.graph.number_of_nodes()} nodes, "
            f"{self.graph.number_of_edges()} edges"
        )

    # ── query ────────────────────────────────────────────────
    def query(self, entity: str, max_depth: int = config.KG_MAX_DEPTH) -> Dict:
        if entity not in self.graph:
            return {}
        node_data = dict(self.graph.nodes[entity])
        related = {
            "neighbors": list(self.graph.neighbors(entity)),
            "predecessors": list(self.graph.predecessors(entity)),
        }
        paths: Dict[str, list] = {}
        for node in list(self.graph.nodes)[:50]:
            if node != entity:
                try:
                    p = nx.shortest_path(self.graph, entity, node)
                    if len(p) <= max_depth + 1:
                        paths[node] = p
                except nx.NetworkXNoPath:
                    pass
        return {
            "entity": entity,
            "data": node_data,
            "related": related,
            "paths": paths,
        }

    # ── persist ──────────────────────────────────────────────
    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump({"graph": self.graph, "entities": dict(self.entities)}, f)

    def load(self, path: str):
        with open(path, "rb") as f:
            data = pickle.load(f)
            self.graph = data["graph"]
            self.entities = defaultdict(set, data["entities"])


# ══════════════════════════════════════════════════════════════
#  Hybrid Retriever
# ══════════════════════════════════════════════════════════════
class HybridRetriever:
    """
    Semantic search (Nomic Embed v1.5 + FAISS)
    + Keyword search (TF-IDF)
    + Knowledge-Graph enhancement
    """

    def __init__(self):
        # ---------- Nomic Embed v1.5 ----------
        logger.info(f"Loading embedding model: {config.EMBEDDING_MODEL} …")
        self.encoder = SentenceTransformer(
            config.EMBEDDING_MODEL,
            trust_remote_code=True,   # required for Nomic
        )
        self.encoder.to("cpu")
        logger.info("Embedding model loaded.")

        # ---------- FAISS ----------
        self.index = None
        self.chunks: List[Dict] = []

        # ---------- TF-IDF ----------
        self.tfidf_vectorizer = TfidfVectorizer(
            max_features=5000,
            ngram_range=(1, 2),
            stop_words="english",
        )
        self.tfidf_matrix = None

        # ---------- Knowledge Graph ----------
        self.kg = KnowledgeGraph()

    # ── Nomic helpers (task-type prefix) ─────────────────────
    def _encode_documents(self, texts: List[str]) -> np.ndarray:
        """Encode documents with 'search_document: ' prefix."""
        prefixed = [config.SEARCH_DOCUMENT_PREFIX + t for t in texts]
        embeddings = self.encoder.encode(
            prefixed,
            show_progress_bar=True,
            batch_size=config.BATCH_SIZE,
            convert_to_numpy=True,
        )
        # Truncate to Matryoshka dim if configured smaller
        if config.MATRYOSHKA_DIM < embeddings.shape[1]:
            embeddings = embeddings[:, : config.MATRYOSHKA_DIM]
        faiss.normalize_L2(embeddings)
        return embeddings

    def _encode_query(self, query: str) -> np.ndarray:
        """Encode a single query with 'search_query: ' prefix."""
        prefixed = config.SEARCH_QUERY_PREFIX + query
        emb = self.encoder.encode([prefixed], convert_to_numpy=True)
        if config.MATRYOSHKA_DIM < emb.shape[1]:
            emb = emb[:, : config.MATRYOSHKA_DIM]
        faiss.normalize_L2(emb)
        return emb

    # ── index ────────────────────────────────────────────────
    def index_documents(self, chunks: List[Dict], use_kg: bool = True):
        """Build FAISS + TF-IDF indices (and optionally KG)."""
        self.chunks = chunks
        texts = [c["content"] for c in chunks]

        # 1. Semantic (FAISS)
        logger.info("Creating Nomic v1.5 embeddings …")
        embeddings = self._encode_documents(texts)
        dimension = embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dimension)
        self.index.add(embeddings)
        logger.info(f"FAISS index: {self.index.ntotal} vectors, dim={dimension}")

        # 2. Keyword (TF-IDF)
        logger.info("Building TF-IDF index …")
        self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(texts)

        # 3. Knowledge graph
        if use_kg:
            self.kg.build_from_chunks(chunks)

    # ── retrieve ─────────────────────────────────────────────
    def retrieve(
        self,
        query: str,
        top_k: int = config.DEFAULT_TOP_K,
        use_hybrid: bool = True,
        use_kg: bool = True,
        semantic_weight: float = config.SEMANTIC_WEIGHT,
        keyword_weight: float = config.KEYWORD_WEIGHT,
    ) -> List[Tuple[Dict, float]]:
        """Hybrid retrieval: semantic + keyword + optional KG boost."""

        # 1. Semantic search
        query_emb = self._encode_query(query)
        distances, indices = self.index.search(query_emb, top_k * 2)

        seen: set = set()
        semantic_results: List[Tuple[Dict, float]] = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < len(self.chunks):
                cid = (
                    self.chunks[idx]["metadata"]["source"],
                    self.chunks[idx]["metadata"]["page"],
                )
                if cid not in seen:
                    seen.add(cid)
                    semantic_results.append((self.chunks[idx], float(dist)))

        if not use_hybrid:
            return semantic_results[:top_k]

        # 2. Keyword search (TF-IDF)
        query_vec = self.tfidf_vectorizer.transform([query])
        kw_scores = (self.tfidf_matrix * query_vec.T).toarray().flatten()
        top_kw_idx = kw_scores.argsort()[-top_k * 2 :][::-1]
        keyword_results: List[Tuple[Dict, float]] = []
        for idx in top_kw_idx:
            if kw_scores[idx] > 0:
                keyword_results.append((self.chunks[idx], float(kw_scores[idx])))

        # 3. Reciprocal Rank Fusion
        combined: Dict[tuple, float] = defaultdict(float)
        for rank, (chunk, _) in enumerate(semantic_results[: top_k * 2]):
            cid = (chunk["metadata"]["source"], chunk["metadata"]["page"])
            combined[cid] += semantic_weight / (rank + 1)
        for rank, (chunk, _) in enumerate(keyword_results):
            cid = (chunk["metadata"]["source"], chunk["metadata"]["page"])
            combined[cid] += keyword_weight / (rank + 1)

        top_ids = sorted(combined.items(), key=lambda x: x[1], reverse=True)[:top_k]
        results: List[Tuple[Dict, float]] = []
        for cid, score in top_ids:
            for chunk in self.chunks:
                if (chunk["metadata"]["source"], chunk["metadata"]["page"]) == cid:
                    results.append((chunk, score))
                    break

        # 4. KG enhancement
        if use_kg and self.kg.graph.number_of_nodes() > 0:
            return self._enhance_with_kg(query, results)

        return results

    # ── KG boost ─────────────────────────────────────────────
    def _enhance_with_kg(
        self, query: str, results: List[Tuple[Dict, float]]
    ) -> List[Tuple[Dict, float]]:
        query_upper = query.upper()
        mentioned = [e for e in self.kg.entities.get("field", set()) if e in query_upper]

        kg_context_parts: List[str] = []
        for entity in mentioned:
            info = self.kg.query(entity)
            if info:
                kg_context_parts.append(f"KG Context for {entity}: {info}")

        if kg_context_parts and results:
            enhanced = []
            for i, (chunk, score) in enumerate(results):
                if i == 0:
                    c = chunk.copy()
                    c["content"] += "\n\n" + "\n".join(kg_context_parts)
                    enhanced.append((c, score))
                else:
                    enhanced.append((chunk, score))
            return enhanced

        return results

    # ── persistence ──────────────────────────────────────────
    def save(self, directory: str):
        os.makedirs(directory, exist_ok=True)
        faiss.write_index(self.index, os.path.join(directory, "faiss.index"))
        with open(os.path.join(directory, "chunks.pkl"), "wb") as f:
            pickle.dump(self.chunks, f)
        with open(os.path.join(directory, "tfidf.pkl"), "wb") as f:
            pickle.dump(
                {"vectorizer": self.tfidf_vectorizer, "matrix": self.tfidf_matrix}, f
            )
        self.kg.save(os.path.join(directory, "kg.pkl"))
        logger.info(f"Indices saved to {directory}")

    def load(self, directory: str):
        self.index = faiss.read_index(os.path.join(directory, "faiss.index"))
        with open(os.path.join(directory, "chunks.pkl"), "rb") as f:
            self.chunks = pickle.load(f)
        with open(os.path.join(directory, "tfidf.pkl"), "rb") as f:
            data = pickle.load(f)
            self.tfidf_vectorizer = data["vectorizer"]
            self.tfidf_matrix = data["matrix"]
        self.kg.load(os.path.join(directory, "kg.pkl"))
        logger.info(f"Indices loaded from {directory}")
