"""
Layer 3 – Chat Orchestrator
=============================
Ties the Text Extraction Service and RAG Service together.
Handles LLM calls, prompt engineering, and the public API.
"""

import os
import pickle
import logging
from typing import List, Dict

import openai

import config
from text_extraction_service import PDFProcessor, SemanticChunker
from rag_service import HybridRetriever

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO))
logger = logging.getLogger(__name__)


class ChatOrchestrator:
    """
    High-level bot that orchestrates:
        1. Text extraction  (Layer 1)
        2. Indexing / retrieval  (Layer 2)
        3. LLM answer generation  (this layer)
    """

    def __init__(
        self,
        llm_api_key: str = config.LLM_API_KEY,
        llm_base_url: str = config.LLM_BASE_URL,
    ):
        # LLM client (OpenAI-compatible)
        self.client = openai.OpenAI(
            api_key=llm_api_key,
            base_url=llm_base_url,
        )

        # Layer 1
        self.pdf_processor = PDFProcessor(use_ocr=config.USE_OCR)
        self.chunker = SemanticChunker(
            chunk_size=config.CHUNK_SIZE,
            overlap=config.CHUNK_OVERLAP,
        )

        # Layer 2
        self.retriever = HybridRetriever()

        # Bookkeeping
        self.processed_pdfs: Dict[str, str] = {}  # name → path

    # ══════════════════════════════════════════════════════════
    #  Process PDFs
    # ══════════════════════════════════════════════════════════
    def process_pdfs(
        self,
        pdf_paths: List[str],
        use_kg: bool = config.USE_KNOWLEDGE_GRAPH,
    ) -> int:
        """
        Extract → chunk → index.  Returns the total number of chunks.
        Accepts any number of PDF file paths.
        """
        all_documents: List[Dict] = []

        for pdf_path in pdf_paths:
            docs = self.pdf_processor.extract_text(pdf_path)
            all_documents.extend(docs)
            self.processed_pdfs[os.path.basename(pdf_path)] = pdf_path

        chunks = self.chunker.chunk_documents(all_documents)
        self.retriever.index_documents(chunks, use_kg=use_kg)
        return len(chunks)

    # ══════════════════════════════════════════════════════════
    #  Ask a question
    # ══════════════════════════════════════════════════════════
    def ask(
        self,
        question: str,
        top_k: int = config.DEFAULT_TOP_K,
        use_hybrid: bool = True,
        use_kg: bool = config.USE_KNOWLEDGE_GRAPH,
    ) -> Dict:
        """Retrieve context and generate an LLM answer."""

        results = self.retriever.retrieve(
            question,
            top_k=top_k,
            use_hybrid=use_hybrid,
            use_kg=use_kg,
        )

        if not results:
            return {
                "answer": "I couldn't find any relevant information in the documents.",
                "sources": [],
                "images": [],
                "confidence": 0.0,
                "pdf_path": None,
                "page_number": None,
                "source_name": None,
            }

        # Build context
        context = "\n\n---\n\n".join(
            f"[Source: {chunk['metadata']['source']}, "
            f"Page {chunk['metadata']['page']}]\n{chunk['content']}"
            for chunk, _ in results
        )

        prompt = self._build_prompt(context, question)

        # LLM call
        try:
            response = self.client.chat.completions.create(
                model=config.LLM_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=config.MAX_TOKENS,
                temperature=config.TEMPERATURE,
            )
            answer = response.choices[0].message.content
        except Exception as e:
            answer = f"Error generating response: {e}"

        # Compile sources & collect images from source pages
        sources = []
        all_images = []          # list of {"path": ..., "page": ..., "source": ...}
        seen_images = set()      # deduplicate by path

        for chunk, score in results:
            meta = chunk["metadata"]
            sources.append({
                "source": meta["source"],
                "page": meta["page"],
                "relevance_score": round(score, 3),
                "pdf_path": meta.get("file_path"),
            })
            # Gather images attached to this chunk's page
            for img_path in meta.get("images", []):
                if img_path not in seen_images and os.path.exists(img_path):
                    seen_images.add(img_path)
                    all_images.append({
                        "path": img_path,
                        "page": meta["page"],
                        "source": meta["source"],
                    })

        primary = sources[0] if sources else {}

        return {
            "answer": answer,
            "sources": sources,
            "images": all_images,
            "confidence": round(results[0][1], 3) if results else 0.0,
            "pdf_path": primary.get("pdf_path"),
            "page_number": primary.get("page"),
            "source_name": primary.get("source"),
        }

    # ══════════════════════════════════════════════════════════
    #  Persistence
    # ══════════════════════════════════════════════════════════
    def save_indices(self, directory: str = config.INDICES_DIR):
        self.retriever.save(directory)
        with open(os.path.join(directory, "pdf_paths.pkl"), "wb") as f:
            pickle.dump(self.processed_pdfs, f)

    def load_indices(self, directory: str = config.INDICES_DIR):
        self.retriever.load(directory)
        paths_file = os.path.join(directory, "pdf_paths.pkl")
        if os.path.exists(paths_file):
            with open(paths_file, "rb") as f:
                self.processed_pdfs = pickle.load(f)

    # ══════════════════════════════════════════════════════════
    #  Prompt template
    # ══════════════════════════════════════════════════════════
    @staticmethod
    def _build_prompt(context: str, question: str) -> str:
        return f"""You are a helpful assistant that answers questions based STRICTLY on the provided technical documentation.

RULES:
1. Only use information from the provided context.
2. If the answer is not in the context, say "I cannot find this information in the provided documents."
3. Cite the source and page number for your answer.
4. If multiple pages have relevant info, mention all of them.
5. Use the exact terminology from the documents.
6. For field definitions, include: field name, description, default values, and any codes/values.
7. Be precise and concise.

CONTEXT:
{context}

QUESTION: {question}

ANSWER (with source citations):"""


# ══════════════════════════════════════════════════════════════
#  Standalone example
# ══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    bot = ChatOrchestrator()

    # Process PDFs (add as many as you need)
    pdf_files = [
        "/path/to/your/document1.pdf",
        "/path/to/your/document2.pdf",
        "/path/to/your/document3.pdf",
        # … add more paths here
    ]

    num_chunks = bot.process_pdfs(pdf_files)
    print(f"Processed {num_chunks} chunks from {len(pdf_files)} files")
    bot.save_indices()

    # Ask questions
    for q in [
        "What is the BATCH ID?",
        "What is the default value for batch number?",
        "What actions can I perform on FI database?",
    ]:
        print(f"\nQ: {q}")
        r = bot.ask(q)
        print(f"A: {r['answer']}")
        print(f"Confidence: {r['confidence']}")
        print(f"Sources: {r['sources']}")
