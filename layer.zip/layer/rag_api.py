"""
RAG Service API (Layer 2)
==========================
FastAPI microservice for document indexing and hybrid retrieval.
Runs on port 8002.

Performance optimisations for 48 GB RAM / CPU:
  - Model loaded once at startup and kept in memory
  - Batched encoding with configurable batch size
  - FAISS IndexIVFFlat for faster search when > 5 000 chunks
  - Numpy-optimised TF-IDF scoring
  - Async endpoints for non-blocking I/O
"""

import os
import re
import pickle
import logging
from typing import List, Dict, Tuple, Optional
from collections import defaultdict

import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
from sklearn.feature_extraction.text import TfidfVectorizer
import networkx as nx
from tqdm import tqdm
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import uvicorn

import config

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO))
logger = logging.getLogger(__name__)

app = FastAPI(
    title="RAG Service",
    description="Layer 2 – Nomic Embed v1.5 + FAISS + TF-IDF + Knowledge Graph",
    version="1.0.0",
)


# ══════════════════════════════════════════════════════════════
#  Pydantic models for request / response
# ══════════════════════════════════════════════════════════════
class ChunkMetadata(BaseModel):
    source: str
    page: int
    file_path: Optional[str] = None
    images: List[str] = Field(default_factory=list)


class Chunk(BaseModel):
    content: str
    metadata: ChunkMetadata


class IndexRequest(BaseModel):
    chunks: List[Chunk]
    use_kg: bool = True


class RetrieveRequest(BaseModel):
    query: str
    top_k: int = config.DEFAULT_TOP_K
    use_hybrid: bool = True
    use_kg: bool = True
    semantic_weight: float = config.SEMANTIC_WEIGHT
    keyword_weight: float = config.KEYWORD_WEIGHT


class RetrieveResult(BaseModel):
    chunk: Dict
    score: float


# ══════════════════════════════════════════════════════════════
#  Knowledge Graph
# ══════════════════════════════════════════════════════════════
class KnowledgeGraph:
    def __init__(self):
        self.graph = nx.DiGraph()
        self.entities: Dict[str, set] = defaultdict(set)

    def build_from_chunks(self, chunks: List[Dict]):
        logger.info("Building knowledge graph …")
        for chunk in tqdm(chunks, desc="KG extraction"):
            content = chunk["content"]
            meta = chunk["metadata"]

            field_matches = re.findall(
                r'([A-Z][A-Z\s]{2,})\s*[:=\-]\s*([^\n]+)', content
            )
            for fname, desc in field_matches:
                fname = fname.strip()
                self.graph.add_node(
                    fname, type="field", description=desc.strip(),
                    page=meta["page"], source=meta["source"],
                )
                self.entities["field"].add(fname)

            for screen in re.findall(r'([A-Z][A-Z0-9]+P[0-9]+)', content):
                self.graph.add_node(screen, type="screen")
                self.entities["screen"].add(screen)

            for val in re.findall(r'(?:Value|Code)[\s:]+([A-Z0-9]+)', content):
                self.graph.add_node(val, type="value")
                self.entities["value"].add(val)

            screens = re.findall(r'([A-Z][A-Z0-9]+P[0-9]+)', content)
            values = re.findall(r'(?:Value|Code)[\s:]+([A-Z0-9]+)', content)
            for fname, _ in field_matches:
                fname = fname.strip()
                for s in screens:
                    self.graph.add_edge(fname, s, relation="appears_in")
                for v in values:
                    self.graph.add_edge(fname, v, relation="has_value")

        logger.info(
            f"KG ready: {self.graph.number_of_nodes()} nodes, "
            f"{self.graph.number_of_edges()} edges"
        )

    def query(self, entity: str, max_depth: int = config.KG_MAX_DEPTH) -> Dict:
        if entity not in self.graph:
            return {}
        node_data = dict(self.graph.nodes[entity])
        related = {
            "neighbors": list(self.graph.neighbors(entity)),
            "predecessors": list(self.graph.predecessors(entity)),
        }
        paths: Dict[str, list] = {}
        for node in list(self.graph.nodes)[:50]:
            if node != entity:
                try:
                    p = nx.shortest_path(self.graph, entity, node)
                    if len(p) <= max_depth + 1:
                        paths[node] = p
                except nx.NetworkXNoPath:
                    pass
        return {"entity": entity, "data": node_data, "related": related, "paths": paths}

    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump({"graph": self.graph, "entities": dict(self.entities)}, f)

    def load(self, path: str):
        with open(path, "rb") as f:
            data = pickle.load(f)
            self.graph = data["graph"]
            self.entities = defaultdict(set, data["entities"])


# ══════════════════════════════════════════════════════════════
#  Hybrid Retriever (singleton – loaded once)
# ══════════════════════════════════════════════════════════════
class HybridRetriever:
    def __init__(self):
        logger.info(f"Loading embedding model: {config.EMBEDDING_MODEL} …")
        self.encoder = SentenceTransformer(
            config.EMBEDDING_MODEL,
            trust_remote_code=True,
        )
        self.encoder.to("cpu")
        logger.info("Embedding model loaded.")

        self.index = None
        self.chunks: List[Dict] = []

        self.tfidf_vectorizer = TfidfVectorizer(
            max_features=5000,
            ngram_range=(1, 2),
            stop_words="english",
        )
        self.tfidf_matrix = None
        self.kg = KnowledgeGraph()
        self._indexed = False

    # ── encoding helpers ─────────────────────
    def _encode_documents(self, texts: List[str]) -> np.ndarray:
        prefixed = [config.SEARCH_DOCUMENT_PREFIX + t for t in texts]
        embeddings = self.encoder.encode(
            prefixed,
            show_progress_bar=True,
            batch_size=config.BATCH_SIZE,
            convert_to_numpy=True,
        )
        if config.MATRYOSHKA_DIM < embeddings.shape[1]:
            embeddings = embeddings[:, : config.MATRYOSHKA_DIM]
        faiss.normalize_L2(embeddings)
        return embeddings

    def _encode_query(self, query: str) -> np.ndarray:
        prefixed = config.SEARCH_QUERY_PREFIX + query
        emb = self.encoder.encode([prefixed], convert_to_numpy=True)
        if config.MATRYOSHKA_DIM < emb.shape[1]:
            emb = emb[:, : config.MATRYOSHKA_DIM]
        faiss.normalize_L2(emb)
        return emb

    # ── index ────────────────────────────────
    def index_documents(self, chunks: List[Dict], use_kg: bool = True):
        self.chunks = chunks
        texts = [c["content"] for c in chunks]

        logger.info(f"Creating embeddings for {len(texts)} chunks …")
        embeddings = self._encode_documents(texts)
        dimension = embeddings.shape[1]

        # Use IVF index for large collections (faster search)
        if len(texts) > 5000:
            nlist = min(int(len(texts) ** 0.5), 256)
            quantizer = faiss.IndexFlatIP(dimension)
            self.index = faiss.IndexIVFFlat(quantizer, dimension, nlist, faiss.METRIC_INNER_PRODUCT)
            self.index.train(embeddings)
            self.index.add(embeddings)
            self.index.nprobe = min(nlist // 4, 32)
            logger.info(f"FAISS IVF index: {self.index.ntotal} vectors, nlist={nlist}")
        else:
            self.index = faiss.IndexFlatIP(dimension)
            self.index.add(embeddings)
            logger.info(f"FAISS flat index: {self.index.ntotal} vectors, dim={dimension}")

        logger.info("Building TF-IDF index …")
        self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(texts)

        if use_kg:
            self.kg.build_from_chunks(chunks)

        self._indexed = True

    # ── retrieve ─────────────────────────────
    def retrieve(
        self,
        query: str,
        top_k: int = config.DEFAULT_TOP_K,
        use_hybrid: bool = True,
        use_kg: bool = True,
        semantic_weight: float = config.SEMANTIC_WEIGHT,
        keyword_weight: float = config.KEYWORD_WEIGHT,
    ) -> List[Tuple[Dict, float]]:

        query_emb = self._encode_query(query)
        distances, indices = self.index.search(query_emb, top_k * 2)

        seen: set = set()
        semantic_results: List[Tuple[Dict, float]] = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < len(self.chunks):
                cid = (
                    self.chunks[idx]["metadata"]["source"],
                    self.chunks[idx]["metadata"]["page"],
                )
                if cid not in seen:
                    seen.add(cid)
                    semantic_results.append((self.chunks[idx], float(dist)))

        if not use_hybrid:
            return semantic_results[:top_k]

        query_vec = self.tfidf_vectorizer.transform([query])
        kw_scores = (self.tfidf_matrix * query_vec.T).toarray().flatten()
        top_kw_idx = kw_scores.argsort()[-top_k * 2:][::-1]
        keyword_results: List[Tuple[Dict, float]] = []
        for idx in top_kw_idx:
            if kw_scores[idx] > 0:
                keyword_results.append((self.chunks[idx], float(kw_scores[idx])))

        combined: Dict[tuple, float] = defaultdict(float)
        for rank, (chunk, _) in enumerate(semantic_results[:top_k * 2]):
            cid = (chunk["metadata"]["source"], chunk["metadata"]["page"])
            combined[cid] += semantic_weight / (rank + 1)
        for rank, (chunk, _) in enumerate(keyword_results):
            cid = (chunk["metadata"]["source"], chunk["metadata"]["page"])
            combined[cid] += keyword_weight / (rank + 1)

        top_ids = sorted(combined.items(), key=lambda x: x[1], reverse=True)[:top_k]
        results: List[Tuple[Dict, float]] = []
        for cid, score in top_ids:
            for chunk in self.chunks:
                if (chunk["metadata"]["source"], chunk["metadata"]["page"]) == cid:
                    results.append((chunk, score))
                    break

        if use_kg and self.kg.graph.number_of_nodes() > 0:
            return self._enhance_with_kg(query, results)
        return results

    # ── KG boost ─────────────────────────────
    def _enhance_with_kg(
        self, query: str, results: List[Tuple[Dict, float]]
    ) -> List[Tuple[Dict, float]]:
        query_upper = query.upper()
        mentioned = [e for e in self.kg.entities.get("field", set()) if e in query_upper]

        kg_context_parts: List[str] = []
        for entity in mentioned:
            info = self.kg.query(entity)
            if info:
                kg_context_parts.append(f"KG Context for {entity}: {info}")

        if kg_context_parts and results:
            enhanced = []
            for i, (chunk, score) in enumerate(results):
                if i == 0:
                    c = chunk.copy()
                    c["content"] += "\n\n" + "\n".join(kg_context_parts)
                    enhanced.append((c, score))
                else:
                    enhanced.append((chunk, score))
            return enhanced
        return results

    # ── persistence ──────────────────────────
    def save(self, directory: str):
        os.makedirs(directory, exist_ok=True)
        faiss.write_index(self.index, os.path.join(directory, "faiss.index"))
        with open(os.path.join(directory, "chunks.pkl"), "wb") as f:
            pickle.dump(self.chunks, f)
        with open(os.path.join(directory, "tfidf.pkl"), "wb") as f:
            pickle.dump(
                {"vectorizer": self.tfidf_vectorizer, "matrix": self.tfidf_matrix}, f
            )
        self.kg.save(os.path.join(directory, "kg.pkl"))
        logger.info(f"Indices saved to {directory}")

    def load(self, directory: str):
        self.index = faiss.read_index(os.path.join(directory, "faiss.index"))
        with open(os.path.join(directory, "chunks.pkl"), "rb") as f:
            self.chunks = pickle.load(f)
        with open(os.path.join(directory, "tfidf.pkl"), "rb") as f:
            data = pickle.load(f)
            self.tfidf_vectorizer = data["vectorizer"]
            self.tfidf_matrix = data["matrix"]
        self.kg.load(os.path.join(directory, "kg.pkl"))
        self._indexed = True
        logger.info(f"Indices loaded from {directory}")


# ══════════════════════════════════════════════════════════════
#  Global singleton – model loaded once at startup
# ══════════════════════════════════════════════════════════════
retriever: Optional[HybridRetriever] = None


@app.on_event("startup")
async def startup():
    global retriever
    retriever = HybridRetriever()
    # Auto-load indices if they exist
    idx_file = os.path.join(config.INDICES_DIR, "faiss.index")
    if os.path.exists(idx_file):
        try:
            retriever.load(config.INDICES_DIR)
            logger.info("Auto-loaded existing indices on startup")
        except Exception as e:
            logger.warning(f"Could not auto-load indices: {e}")


# ══════════════════════════════════════════════════════════════
#  API Endpoints
# ══════════════════════════════════════════════════════════════
@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "rag-service",
        "indexed": retriever._indexed if retriever else False,
        "num_chunks": len(retriever.chunks) if retriever else 0,
    }


@app.post("/index")
async def index_documents(req: IndexRequest):
    """Index a list of chunks (build FAISS + TF-IDF + KG)."""
    if not retriever:
        raise HTTPException(503, "Retriever not initialised")

    chunks = [c.dict() for c in req.chunks]
    retriever.index_documents(chunks, use_kg=req.use_kg)

    return {
        "status": "indexed",
        "num_chunks": len(chunks),
        "faiss_vectors": retriever.index.ntotal,
        "kg_nodes": retriever.kg.graph.number_of_nodes(),
        "kg_edges": retriever.kg.graph.number_of_edges(),
    }


@app.post("/retrieve")
async def retrieve(req: RetrieveRequest):
    """Hybrid retrieval: semantic + keyword + KG."""
    if not retriever or not retriever._indexed:
        raise HTTPException(400, "No documents indexed yet. Call /index first.")

    results = retriever.retrieve(
        query=req.query,
        top_k=req.top_k,
        use_hybrid=req.use_hybrid,
        use_kg=req.use_kg,
        semantic_weight=req.semantic_weight,
        keyword_weight=req.keyword_weight,
    )

    return {
        "query": req.query,
        "num_results": len(results),
        "results": [
            {"chunk": chunk, "score": round(score, 4)}
            for chunk, score in results
        ],
    }


@app.post("/save")
async def save_indices(directory: str = config.INDICES_DIR):
    """Persist FAISS + TF-IDF + KG to disk."""
    if not retriever or not retriever._indexed:
        raise HTTPException(400, "Nothing to save – index documents first")
    retriever.save(directory)
    return {"status": "saved", "directory": directory}


@app.post("/load")
async def load_indices(directory: str = config.INDICES_DIR):
    """Load persisted indices from disk."""
    if not retriever:
        raise HTTPException(503, "Retriever not initialised")
    idx_file = os.path.join(directory, "faiss.index")
    if not os.path.exists(idx_file):
        raise HTTPException(404, f"No index found in {directory}")
    retriever.load(directory)
    return {
        "status": "loaded",
        "num_chunks": len(retriever.chunks),
        "faiss_vectors": retriever.index.ntotal,
    }


@app.get("/stats")
def stats():
    """Return current index statistics."""
    if not retriever:
        raise HTTPException(503, "Not initialised")
    return {
        "indexed": retriever._indexed,
        "num_chunks": len(retriever.chunks),
        "faiss_vectors": retriever.index.ntotal if retriever.index else 0,
        "kg_nodes": retriever.kg.graph.number_of_nodes(),
        "kg_edges": retriever.kg.graph.number_of_edges(),
    }


# ══════════════════════════════════════════════════════════════
#  Run
# ══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    uvicorn.run(
        "rag_api:app",
        host="0.0.0.0",
        port=8002,
        workers=1,  # single worker – model in memory
        log_level="info",
    )
