"""
Chat Orchestrator API (Layer 3)
================================
FastAPI microservice that ties Text Extraction and RAG services together.
Handles LLM calls, prompt engineering, and the public-facing API.
Runs on port 8003.

Calls:
  - Text Extraction API (port 8001) for PDF processing
  - RAG Service API     (port 8002) for indexing & retrieval
  - LLM provider        (OpenAI-compatible) for answer generation
"""

import os
import pickle
import logging
from typing import List, Dict, Optional

import openai
import httpx
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from pydantic import BaseModel, Field
import uvicorn

import config

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO))
logger = logging.getLogger(__name__)

# Service URLs (env vars override config for Docker)
TEXT_EXTRACTION_URL = os.environ.get(
    "TEXT_EXTRACTION_URL",
    getattr(config, "TEXT_EXTRACTION_URL", "http://localhost:8001"),
)
RAG_SERVICE_URL = os.environ.get(
    "RAG_SERVICE_URL",
    getattr(config, "RAG_SERVICE_URL", "http://localhost:8002"),
)

app = FastAPI(
    title="Chat Orchestrator",
    description="Layer 3 – Orchestrates extraction, indexing, retrieval, and LLM answer generation",
    version="1.0.0",
)

# Shared HTTP client – generous timeout for large PDF processing on CPU
http_client = httpx.AsyncClient(timeout=httpx.Timeout(1800.0, connect=60.0))

# LLM client
llm_client: Optional[openai.OpenAI] = None

# Bookkeeping
processed_pdfs: Dict[str, str] = {}  # filename → pdf_path


# ══════════════════════════════════════════════════════════════
#  Pydantic models
# ══════════════════════════════════════════════════════════════
class AskRequest(BaseModel):
    question: str
    top_k: int = config.DEFAULT_TOP_K
    use_hybrid: bool = True
    use_kg: bool = True


class AskResponse(BaseModel):
    answer: str
    sources: List[Dict] = Field(default_factory=list)
    images: List[Dict] = Field(default_factory=list)
    confidence: float = 0.0
    pdf_path: Optional[str] = None
    page_number: Optional[int] = None
    source_name: Optional[str] = None


# ══════════════════════════════════════════════════════════════
#  Prompt template (same as original)
# ══════════════════════════════════════════════════════════════
def _build_prompt(context: str, question: str) -> str:
    return f"""You are a helpful assistant that answers questions based STRICTLY on the provided technical documentation.

RULES:
1. Only use information from the provided context.
2. If the answer is not in the context, say "I cannot find this information in the provided documents."
3. Cite the source and page number for your answer.
4. If multiple pages have relevant info, mention all of them.
5. Use the exact terminology from the documents.
6. For field definitions, include: field name, description, default values, and any codes/values.
7. Be precise and concise.

CONTEXT:
{context}

QUESTION: {question}

ANSWER (with source citations):"""


# ══════════════════════════════════════════════════════════════
#  Startup / Shutdown
# ══════════════════════════════════════════════════════════════
@app.on_event("startup")
async def startup():
    global llm_client
    api_key = config.LLM_API_KEY
    if api_key and api_key != "your-api-key-here":
        llm_client = openai.OpenAI(api_key=api_key, base_url=config.LLM_BASE_URL)
        logger.info("LLM client initialised")
    else:
        logger.warning("No LLM_API_KEY configured – /ask will fail")

    # Load saved pdf_paths if any
    global processed_pdfs
    paths_file = os.path.join(config.INDICES_DIR, "pdf_paths.pkl")
    if os.path.exists(paths_file):
        with open(paths_file, "rb") as f:
            processed_pdfs = pickle.load(f)
        logger.info(f"Loaded {len(processed_pdfs)} processed PDF paths")


@app.on_event("shutdown")
async def shutdown():
    await http_client.aclose()


# ══════════════════════════════════════════════════════════════
#  API Endpoints
# ══════════════════════════════════════════════════════════════
@app.get("/health")
async def health():
    # Report own status as OK even if downstream services are not yet started.
    # Downstream status is informational only.
    svc_status = {}
    for name, url in [("text-extraction", TEXT_EXTRACTION_URL), ("rag-service", RAG_SERVICE_URL)]:
        try:
            r = await http_client.get(f"{url}/health", timeout=5.0)
            svc_status[name] = r.json()
        except Exception as e:
            svc_status[name] = {"status": "unreachable", "error": str(e)}

    return {
        "status": "ok",
        "service": "chat-orchestrator",
        "llm_configured": llm_client is not None,
        "downstream": svc_status,
    }


@app.post("/process")
async def process_pdfs(
    files: List[UploadFile] = File(...),
    use_ocr: bool = Form(True),
    use_kg: bool = Form(True),
    chunk_size: int = Form(config.CHUNK_SIZE),
    overlap: int = Form(config.CHUNK_OVERLAP),
):
    """
    Upload PDFs → extract text → chunk → index.
    Calls Text Extraction API and RAG Service API.
    Returns total chunks indexed.
    """
    all_chunks: List[Dict] = []

    # Step 1: Send each PDF to the text extraction service
    for uploaded_file in files:
        logger.info(f"Sending {uploaded_file.filename} to text extraction service …")

        # Read file bytes once
        file_bytes = await uploaded_file.read()

        resp = await http_client.post(
            f"{TEXT_EXTRACTION_URL}/extract_and_chunk",
            files={"file": (uploaded_file.filename, file_bytes, "application/pdf")},
            data={
                "use_ocr": str(use_ocr).lower(),
                "chunk_size": str(chunk_size),
                "overlap": str(overlap),
            },
        )

        if resp.status_code != 200:
            raise HTTPException(
                resp.status_code,
                f"Text extraction failed for {uploaded_file.filename}: {resp.text}",
            )

        result = resp.json()
        all_chunks.extend(result["chunks"])
        processed_pdfs[uploaded_file.filename] = result.get("pdf_path", "")
        logger.info(
            f"{uploaded_file.filename}: {result['num_pages']} pages → {result['num_chunks']} chunks"
        )

    if not all_chunks:
        raise HTTPException(400, "No chunks extracted from any PDF")

    # Step 2: Send chunks to RAG service for indexing
    logger.info(f"Sending {len(all_chunks)} chunks to RAG service for indexing …")
    resp = await http_client.post(
        f"{RAG_SERVICE_URL}/index",
        json={"chunks": all_chunks, "use_kg": use_kg},
    )

    if resp.status_code != 200:
        raise HTTPException(resp.status_code, f"Indexing failed: {resp.text}")

    index_result = resp.json()

    # Step 3: Save indices
    await http_client.post(f"{RAG_SERVICE_URL}/save")

    # Save pdf_paths locally
    os.makedirs(config.INDICES_DIR, exist_ok=True)
    with open(os.path.join(config.INDICES_DIR, "pdf_paths.pkl"), "wb") as f:
        pickle.dump(processed_pdfs, f)

    return {
        "status": "processed",
        "num_files": len(files),
        "total_chunks": index_result["num_chunks"],
        "faiss_vectors": index_result["faiss_vectors"],
        "kg_nodes": index_result.get("kg_nodes", 0),
        "kg_edges": index_result.get("kg_edges", 0),
    }


@app.post("/ask", response_model=AskResponse)
async def ask(req: AskRequest):
    """Retrieve context from RAG service and generate an LLM answer."""
    if not llm_client:
        raise HTTPException(503, "LLM not configured – set LLM_API_KEY in config.py")

    # Step 1: Retrieve from RAG service
    resp = await http_client.post(
        f"{RAG_SERVICE_URL}/retrieve",
        json=req.dict(),
    )

    if resp.status_code != 200:
        raise HTTPException(resp.status_code, f"Retrieval failed: {resp.text}")

    rag_result = resp.json()
    results = rag_result.get("results", [])

    if not results:
        return AskResponse(
            answer="I couldn't find any relevant information in the documents.",
        )

    # Step 2: Build context
    context = "\n\n---\n\n".join(
        f"[Source: {r['chunk']['metadata']['source']}, "
        f"Page {r['chunk']['metadata']['page']}]\n{r['chunk']['content']}"
        for r in results
    )

    prompt = _build_prompt(context, req.question)

    # Step 3: LLM call
    try:
        response = llm_client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=config.MAX_TOKENS,
            temperature=config.TEMPERATURE,
        )
        answer = response.choices[0].message.content
    except Exception as e:
        answer = f"Error generating response: {e}"

    # Step 4: Compile sources & images
    sources = []
    all_images = []
    seen_images = set()

    for r in results:
        meta = r["chunk"]["metadata"]
        sources.append({
            "source": meta["source"],
            "page": meta["page"],
            "relevance_score": round(r["score"], 3),
            "pdf_path": meta.get("file_path"),
        })
        for img_path in meta.get("images", []):
            if img_path not in seen_images and os.path.exists(img_path):
                seen_images.add(img_path)
                all_images.append({
                    "path": img_path,
                    "page": meta["page"],
                    "source": meta["source"],
                })

    primary = sources[0] if sources else {}

    return AskResponse(
        answer=answer,
        sources=sources,
        images=all_images,
        confidence=round(results[0]["score"], 3) if results else 0.0,
        pdf_path=primary.get("pdf_path"),
        page_number=primary.get("page"),
        source_name=primary.get("source"),
    )


@app.post("/load_indices")
async def load_indices():
    """Tell RAG service to load persisted indices."""
    resp = await http_client.post(f"{RAG_SERVICE_URL}/load")
    if resp.status_code != 200:
        raise HTTPException(resp.status_code, f"Failed to load indices: {resp.text}")

    # Also load pdf_paths
    global processed_pdfs
    paths_file = os.path.join(config.INDICES_DIR, "pdf_paths.pkl")
    if os.path.exists(paths_file):
        with open(paths_file, "rb") as f:
            processed_pdfs = pickle.load(f)

    return resp.json()


@app.get("/stats")
async def stats():
    """Fetch stats from RAG service."""
    try:
        resp = await http_client.get(f"{RAG_SERVICE_URL}/stats")
        rag_stats = resp.json() if resp.status_code == 200 else {}
    except Exception:
        rag_stats = {}
    return {
        "processed_pdfs": len(processed_pdfs),
        "pdf_names": list(processed_pdfs.keys()),
        "rag": rag_stats,
    }


# ══════════════════════════════════════════════════════════════
#  Run
# ══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    uvicorn.run(
        "chat_api:app",
        host="0.0.0.0",
        port=8003,
        workers=1,
        timeout_keep_alive=300,
        log_level="info",
    )
