# Configuration for PDF Knowledge Bot
# ====================================
# All LLM / model settings are configured here.
# No environment variable exports needed.

# ──────────────────────────────────────────────
# LLM Configuration (Llama 3.3 70B or any OpenAI-compatible model)
# ──────────────────────────────────────────────
LLM_MODEL = "llama-3.3-70b"          # Model name sent to the API
LLM_API_KEY = "your-api-key-here"    # Replace with your actual API key
LLM_BASE_URL = "https://api.openai.com/v1"
# Provider examples:
#   OpenRouter  → "https://openrouter.ai/api/v1"
#   Together AI → "https://api.together.xyz/v1"
#   Groq        → "https://api.groq.com/openai/v1"

MAX_TOKENS = 2000   # Max tokens in LLM response
TEMPERATURE = 0     # 0 = deterministic answers

# ──────────────────────────────────────────────
# Embedding Model – Nomic Embed v1.5
# ──────────────────────────────────────────────
EMBEDDING_MODEL = "nomic-ai/nomic-embed-text-v1.5"
EMBEDDING_DIMENSION = 768      # Nomic v1.5 output dimension
MATRYOSHKA_DIM = 768           # Can reduce to 512 / 256 / 128 for speed

# Nomic v1.5 requires task-type prefixes:
SEARCH_QUERY_PREFIX = "search_query: "
SEARCH_DOCUMENT_PREFIX = "search_document: "

# ──────────────────────────────────────────────
# Chunking Configuration
# ──────────────────────────────────────────────
CHUNK_SIZE = 800    # Words per chunk
CHUNK_OVERLAP = 150 # Overlap for context preservation

# ──────────────────────────────────────────────
# Retrieval Configuration
# ──────────────────────────────────────────────
DEFAULT_TOP_K = 5          # Number of chunks to retrieve
SEMANTIC_WEIGHT = 0.6      # Weight for semantic search (0-1)
KEYWORD_WEIGHT = 0.4       # Weight for keyword search (0-1)

# ──────────────────────────────────────────────
# Processing Configuration
# ──────────────────────────────────────────────
USE_OCR = True              # Enable OCR for scanned PDFs
USE_KNOWLEDGE_GRAPH = True  # Build knowledge graph
BATCH_SIZE = 32             # Embedding batch size (reduce if OOM)

# ──────────────────────────────────────────────
# FAISS Configuration
# ──────────────────────────────────────────────
FAISS_INDEX_TYPE = "IndexFlatIP"  # Inner Product (cosine similarity)

# ──────────────────────────────────────────────
# OCR Configuration
# ──────────────────────────────────────────────
TESSERACT_CONFIG = "--oem 3 --psm 6"
OCR_DPI = 300

# ──────────────────────────────────────────────
# Knowledge Graph Configuration
# ──────────────────────────────────────────────
KG_MAX_DEPTH = 2
KG_ENTITY_TYPES = ["field", "screen", "value", "code"]

# ──────────────────────────────────────────────
# Storage Configuration
# ──────────────────────────────────────────────
INDICES_DIR = "./indices"
TEMP_DIR = "./temp_pdfs"
UPLOADED_PDFS_DIR = "./uploaded_pdfs"
EXTRACTED_IMAGES_DIR = "./extracted_images"  # Images pulled from PDF pages

# ──────────────────────────────────────────────
# Microservice API URLs (used by chat_api and app.py)
# ──────────────────────────────────────────────
TEXT_EXTRACTION_URL = "http://localhost:8001"   # Text Extraction API
RAG_SERVICE_URL     = "http://localhost:8002"   # RAG Service API
CHAT_API_URL        = "http://localhost:8003"   # Chat Orchestrator API

# ──────────────────────────────────────────────
# Logging
# ──────────────────────────────────────────────
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
