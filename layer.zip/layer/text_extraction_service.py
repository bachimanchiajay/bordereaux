"""
Layer 1 – Text Extraction Service
==================================
Handles PDF text extraction with OCR fallback.
Also extracts embedded images from each page.
"""

import os
import re
import io
import hashlib
import logging
from typing import List, Dict
from pathlib import Path

import fitz                    # PyMuPDF – fast PDF text extraction
from PIL import Image
import pytesseract             # OCR fallback for scanned pages
from tqdm import tqdm

import config

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO))
logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# PDF Processor
# ──────────────────────────────────────────────────────────────
class PDFProcessor:
    """Extract text and images from PDFs with optional OCR."""

    def __init__(self, use_ocr: bool = True):
        self.use_ocr = use_ocr
        # Create image output directory
        self.images_dir = Path(config.EXTRACTED_IMAGES_DIR)
        self.images_dir.mkdir(parents=True, exist_ok=True)

    def extract_text(self, pdf_path: str) -> List[Dict]:
        """
        Extract text and images from every page of a PDF.

        Returns a list of dicts, each with:
            - content  : str        (extracted text)
            - metadata : dict       (source, page, file_path, images)
        """
        logger.info(f"Processing PDF: {pdf_path}")
        documents: List[Dict] = []
        doc = fitz.open(pdf_path)
        pdf_stem = Path(pdf_path).stem

        for page_num in tqdm(range(len(doc)), desc=f"Extracting {Path(pdf_path).name}"):
            page = doc[page_num]

            # ── Text ──────────────────────────────────────
            text = page.get_text()
            if self.use_ocr and (not text or len(text.strip()) < 50):
                text = self._ocr_page(page)

            # ── Images ────────────────────────────────────
            page_images = self._extract_images(doc, page, pdf_stem, page_num + 1)

            if (text and text.strip()) or page_images:
                documents.append({
                    "content": text.strip() if text else "",
                    "metadata": {
                        "source": os.path.basename(pdf_path),
                        "page": page_num + 1,
                        "file_path": pdf_path,
                        "images": page_images,  # list of saved image paths
                    },
                })

        doc.close()
        logger.info(
            f"Extracted {len(documents)} pages from {pdf_path}"
        )
        return documents

    # ------------------------------------------------------------------ #
    #  Private helpers
    # ------------------------------------------------------------------ #
    def _ocr_page(self, page) -> str:
        """OCR a single page using Tesseract."""
        try:
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))  # 2× zoom
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            text = pytesseract.image_to_string(img, config=config.TESSERACT_CONFIG)
            return text
        except Exception as e:
            logger.warning(f"OCR failed: {e}")
            return ""

    def _extract_images(self, doc, page, pdf_stem: str, page_number: int) -> List[str]:
        """
        Extract every embedded image from a PDF page.
        Saves them to disk and returns a list of file paths.
        """
        saved_paths: List[str] = []
        try:
            image_list = page.get_images(full=True)
            for img_index, img_info in enumerate(image_list):
                xref = img_info[0]
                try:
                    base_image = doc.extract_image(xref)
                    if base_image is None:
                        continue

                    image_bytes = base_image["image"]
                    ext = base_image.get("ext", "png")

                    # Skip tiny images (icons / spacers)
                    if len(image_bytes) < 2048:
                        continue

                    # Deterministic filename so re-processing doesn't duplicate
                    img_hash = hashlib.md5(image_bytes).hexdigest()[:10]
                    filename = f"{pdf_stem}_p{page_number}_i{img_index}_{img_hash}.{ext}"
                    out_path = self.images_dir / filename

                    if not out_path.exists():
                        out_path.write_bytes(image_bytes)

                    saved_paths.append(str(out_path))
                except Exception:
                    continue
        except Exception as e:
            logger.debug(f"Image extraction skipped page {page_number}: {e}")

        return saved_paths


# ──────────────────────────────────────────────────────────────
# Semantic Chunker
# ──────────────────────────────────────────────────────────────
class SemanticChunker:
    """Split extracted documents into overlapping chunks that preserve context."""

    def __init__(
        self,
        chunk_size: int = config.CHUNK_SIZE,
        overlap: int = config.CHUNK_OVERLAP,
    ):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk_documents(self, documents: List[Dict]) -> List[Dict]:
        """Break documents into chunks while trying to respect section boundaries."""
        chunks: List[Dict] = []

        for doc in documents:
            content = doc["content"]
            sections = self._identify_sections(content)

            parts = sections if sections else [content]
            for part in parts:
                for chunk_text in self._chunk_text(part):
                    chunks.append({
                        "content": chunk_text,
                        "metadata": doc["metadata"].copy(),
                    })

        logger.info(f"Created {len(chunks)} chunks from {len(documents)} pages")
        return chunks

    # ------------------------------------------------------------------ #
    def _identify_sections(self, text: str) -> List[str]:
        """Detect logical sections in technical documentation."""
        sections: List[str] = []
        patterns = [
            r'^[A-Z\s]+:.*?(?=^[A-Z\s]+:|$)',
            r'^[A-Z][a-zA-Z\s]+\n[=\-]{3,}.*?(?=^[A-Z][a-zA-Z\s]+\n[=\-]{3,}|$)',
            r'(?:Default Value|Functional Impact|Output|Description|Value)[\s:]+.*?(?=(?:Default Value|Functional Impact|Output|Description)|$)',
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, text, re.MULTILINE | re.DOTALL):
                section = match.group(0).strip()
                if len(section) > 50:
                    sections.append(section)

        return sections if sections else []

    def _chunk_text(self, text: str) -> List[str]:
        """Word-level chunking with overlap."""
        words = text.split()
        step = max(1, self.chunk_size - self.overlap)
        result: List[str] = []
        for i in range(0, len(words), step):
            chunk = " ".join(words[i : i + self.chunk_size])
            if chunk.strip():
                result.append(chunk)
        return result
