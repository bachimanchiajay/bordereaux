# 📚 PDF Knowledge Bot

> Ask questions about your PDF documents using **Nomic Embed v1.5** embeddings, **FAISS** vector search, and **Llama 3.3 70B** (or any OpenAI-compatible LLM).

---

## Architecture – Three Service Layers

```
┌──────────────────────────────────────────────────────────┐
│  app.py  (Streamlit UI)                                  │
│  ┌────────────────────────────────────────────────────┐  │
│  │  Layer 3 – chat_orchestrator.py                    │  │
│  │  LLM calls · prompt engineering · public API       │  │
│  │  ┌──────────────────┐  ┌────────────────────────┐  │  │
│  │  │ Layer 1           │  │ Layer 2                │  │  │
│  │  │ text_extraction   │  │ rag_service.py         │  │  │
│  │  │ _service.py       │  │ Nomic Embed v1.5       │  │  │
│  │  │ PDF text + OCR    │  │ FAISS + TF-IDF         │  │  │
│  │  │ Chunking          │  │ Knowledge Graph        │  │  │
│  │  └──────────────────┘  └────────────────────────┘  │  │
│  └────────────────────────────────────────────────────┘  │
│  config.py  (all settings in one place)                  │
└──────────────────────────────────────────────────────────┘
```

| File | Purpose |
|---|---|
| `config.py` | **All** configuration: LLM model/key/URL, embedding model, chunking, retrieval, OCR, storage |
| `text_extraction_service.py` | Layer 1 – PDF → text (PyMuPDF + Tesseract OCR), semantic chunking |
| `rag_service.py` | Layer 2 – Nomic Embed v1.5 embeddings, FAISS index, TF-IDF, Knowledge Graph, hybrid retrieval |
| `chat_orchestrator.py` | Layer 3 – Ties Layer 1 + 2 together, LLM prompt building, answer generation |
| `app.py` | Streamlit web UI with split-screen PDF viewer |

---

## Prerequisites

| Requirement | Notes |
|---|---|
| **Python 3.11.x** | 3.11.9 recommended |
| **Tesseract OCR** | Only needed if `USE_OCR = True` in config |
| **LLM API key** | For Llama 3.3 70B or any OpenAI-compatible provider |
| **~2 GB disk** | For Nomic Embed v1.5 model download (first run) |

---

## 🖥️ Running WITHOUT Docker (Windows 11 VM)

### Step 1 — Install Python 3.11

1. Download from <https://www.python.org/downloads/release/python-3119/>
2. During install, **check "Add Python to PATH"**
3. Verify:
   ```powershell
   python --version       # Should show 3.11.9
   pip --version
   ```

### Step 2 — Install Tesseract OCR (optional, for scanned PDFs)

1. Download the installer from <https://github.com/UB-Mannheim/tesseract/wiki>
2. Install to the default path: `C:\Program Files\Tesseract-OCR`
3. Add to PATH:
   ```powershell
   # Run in an Administrator PowerShell:
   [System.Environment]::SetEnvironmentVariable(
       "Path",
       $env:Path + ";C:\Program Files\Tesseract-OCR",
       [System.EnvironmentVariableTarget]::Machine
   )
   ```
4. Verify:
   ```powershell
   tesseract --version
   ```

> If you don't need OCR, set `USE_OCR = False` in `config.py` and skip this step.

### Step 3 — Install Git (optional but recommended)

Download from <https://git-scm.com/download/win> and install with defaults.

### Step 4 — Get the code

**Option A — Clone from Git:**
```powershell
git clone <your-repo-url> pdf-knowledge-bot
cd pdf-knowledge-bot
```

**Option B — Copy files manually:**

Copy all project files into a folder, e.g. `C:\pdf-knowledge-bot`, then:
```powershell
cd C:\pdf-knowledge-bot
```

### Step 5 — Create a virtual environment

```powershell
python -m venv venv
venv\Scripts\activate
```

You should see `(venv)` in your prompt.

### Step 6 — Install PyTorch (CPU) + dependencies

```powershell
# Install CPU-only PyTorch first (saves ~1.5 GB vs GPU build)
pip install torch --index-url https://download.pytorch.org/whl/cpu

# Install remaining dependencies
pip install -r requirements.txt
```

> ⏱ First run will download the Nomic Embed v1.5 model (~550 MB). This is automatic.

### Step 7 — Configure

Edit `config.py` and set your values:

```python
LLM_MODEL   = "llama-3.3-70b"                 # your model name
LLM_API_KEY = "sk-your-actual-api-key-here"    # your API key
LLM_BASE_URL = "https://api.openai.com/v1"     # your provider URL
```

**Provider URL examples:**

| Provider | `LLM_BASE_URL` |
|---|---|
| OpenAI | `https://api.openai.com/v1` |
| OpenRouter | `https://openrouter.ai/api/v1` |
| Together AI | `https://api.together.xyz/v1` |
| Groq | `https://api.groq.com/openai/v1` |

### Step 8 — Run the app

```powershell
streamlit run app.py
```

The app opens at **http://localhost:8501**

### Step 9 — Use the app

1. Click **Initialize Bot** in the sidebar (this loads the embedding model — first time takes ~1 min)
2. Go to the **Upload & Process** tab
3. Upload one or more PDF files
4. Click **🚀 Process PDFs**
5. Switch to the **Ask Questions** tab
6. Type a question and click **🔍 Ask**

---

## 🐳 Running WITH Docker (Windows 11 VM)

### Step 1 — Install Docker Desktop

1. Download from <https://www.docker.com/products/docker-desktop/>
2. Install and restart your machine
3. Open Docker Desktop and wait until the engine is running
4. Verify:
   ```powershell
   docker --version
   docker compose version
   ```

### Step 2 — Configure

Edit `config.py` exactly as in Step 7 above (set `LLM_MODEL`, `LLM_API_KEY`, `LLM_BASE_URL`).

### Step 3 — Build and run

```powershell
cd C:\pdf-knowledge-bot

# Build the image (first time takes 5-10 min)
docker compose build

# Start the container
docker compose up -d
```

The app is available at **http://localhost:8501**

### Useful Docker commands

```powershell
# View logs
docker compose logs -f

# Stop
docker compose down

# Rebuild after code changes
docker compose build --no-cache
docker compose up -d

# Shell into the container
docker compose exec pdf-knowledge-bot bash
```

### How Docker volumes work

| Host path | Container path | Purpose |
|---|---|---|
| `./indices/` | `/app/indices/` | Saved FAISS/TF-IDF/KG indices |
| `./uploaded_pdfs/` | `/app/uploaded_pdfs/` | Uploaded PDF files |
| `./extracted_images/` | `/app/extracted_images/` | Images extracted from PDF pages |
| `./config.py` | `/app/config.py` | Config (edit without rebuild) |

---

## 🧪 Running via CLI (no Streamlit)

You can use the bot programmatically:

```python
from chat_orchestrator import ChatOrchestrator

bot = ChatOrchestrator()                    # reads config.py automatically

# Process PDFs
bot.process_pdfs([
    r"C:\docs\manual1.pdf",
    r"C:\docs\manual2.pdf",
    r"C:\docs\manual3.pdf",
    # add as many as needed
])
bot.save_indices()

# Ask questions
result = bot.ask("What is the BATCH ID?")
print(result["answer"])
print(result["sources"])
```

Or run the built-in example:
```powershell
python chat_orchestrator.py
```

---

## ⚙️ Configuration Reference (`config.py`)

| Setting | Default | Description |
|---|---|---|
| `LLM_MODEL` | `"llama-3.3-70b"` | Model name sent to the API |
| `LLM_API_KEY` | `"your-api-key-here"` | Your API key |
| `LLM_BASE_URL` | `"https://api.openai.com/v1"` | Provider endpoint |
| `MAX_TOKENS` | `2000` | Max response tokens |
| `TEMPERATURE` | `0` | 0 = deterministic |
| `EMBEDDING_MODEL` | `"nomic-ai/nomic-embed-text-v1.5"` | Embedding model |
| `MATRYOSHKA_DIM` | `768` | Dimension (768/512/256/128) |
| `CHUNK_SIZE` | `800` | Words per chunk |
| `CHUNK_OVERLAP` | `150` | Overlapping words |
| `DEFAULT_TOP_K` | `5` | Chunks to retrieve |
| `SEMANTIC_WEIGHT` | `0.6` | Semantic search weight |
| `KEYWORD_WEIGHT` | `0.4` | TF-IDF search weight |
| `USE_OCR` | `True` | OCR for scanned pages |
| `USE_KNOWLEDGE_GRAPH` | `True` | Build entity graph |

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `tesseract is not installed` | Install Tesseract and add to PATH, or set `USE_OCR = False` |
| `torch` install fails | Use `pip install torch --index-url https://download.pytorch.org/whl/cpu` |
| Out of memory on large PDFs | Reduce `BATCH_SIZE` in config.py (e.g. 8 or 16) |
| Slow first run | Normal — Nomic model downloads once (~550 MB) |
| `trust_remote_code` warning | Expected with Nomic v1.5 — safe to accept |
| Docker build slow | First build downloads PyTorch + model; subsequent builds use cache |
| Port 8501 in use | `docker compose down` or change port in `docker-compose.yml` |

---

## Project Structure

```
pdf-knowledge-bot/
├── config.py                      # All configuration
├── text_extraction_service.py     # Layer 1: PDF → text → chunks + images
├── rag_service.py                 # Layer 2: Embeddings + FAISS + KG
├── chat_orchestrator.py           # Layer 3: LLM + orchestration
├── app.py                         # Streamlit web UI
├── requirements.txt               # Python dependencies (3.11.9)
├── Dockerfile                     # Container build (Python 3.11)
├── docker-compose.yml             # Container orchestration
├── README.md                      # This file
├── indices/                       # Saved indices (auto-created)
├── uploaded_pdfs/                 # Uploaded files (auto-created)
└── extracted_images/              # Images from PDF pages (auto-created)
```
