# 📚 PDF Knowledge Bot – Microservice Architecture

> Ask questions about your PDF documents using **Nomic Embed v1.5** embeddings, **FAISS** vector search, and **Llama 3.3 70B** (or any OpenAI-compatible LLM).
>
> Split into **3 independent API services** for speed on CPU machines.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│  Browser → http://localhost:8501                             │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  app.py  (Streamlit UI · Port 8501)                    │  │
│  │  PDF viewer · Chat history · Upload form               │  │
│  └──────────────────────┬─────────────────────────────────┘  │
│                         │ HTTP                               │
│  ┌──────────────────────▼─────────────────────────────────┐  │
│  │  chat_api.py  (Port 8003)                              │  │
│  │  Orchestrator – coordinates everything + LLM calls     │  │
│  └────────┬─────────────────────────────┬─────────────────┘  │
│           │ HTTP                        │ HTTP               │
│  ┌────────▼──────────┐       ┌──────────▼────────────────┐  │
│  │ text_extraction   │       │ rag_api.py (Port 8002)    │  │
│  │ _api.py (Port 8001)│       │                          │  │
│  │                   │       │ Nomic Embed v1.5 model    │  │
│  │ PyMuPDF + OCR     │       │ FAISS vector index        │  │
│  │ Multiprocess pages│       │ TF-IDF keyword index      │  │
│  │ Semantic chunking │       │ Knowledge Graph           │  │
│  └───────────────────┘       └───────────────────────────┘  │
│                                                              │
│  config.py  (all settings in one place)                      │
└──────────────────────────────────────────────────────────────┘
```

| File | Port | Purpose |
|---|---|---|
| `text_extraction_api.py` | 8001 | PDF → text extraction (OCR), image extraction, chunking |
| `rag_api.py` | 8002 | Nomic Embed v1.5 embeddings, FAISS + TF-IDF indexing, Knowledge Graph, hybrid retrieval |
| `chat_api.py` | 8003 | Orchestrates Service 1 + 2, builds prompts, calls LLM |
| `app.py` | 8501 | Streamlit web UI with split-screen PDF viewer |
| `config.py` | — | All configuration (LLM, embeddings, chunking, retrieval, service URLs) |
| `start_services.py` | — | Launches all 4 processes with one command |

---

## Prerequisites

| Requirement | Notes |
|---|---|
| **Python 3.11.x** | 3.11.9 recommended |
| **Tesseract OCR** | Only needed if `USE_OCR = True` in config |
| **LLM API key** | For Llama 3.3 70B or any OpenAI-compatible provider |
| **~2 GB disk** | For Nomic Embed v1.5 model download (first run) |
| **48 GB RAM** | Recommended; 16 GB minimum |

---

## 🖥️ Running WITHOUT Docker (Windows 11 VM)

### Step 1 — Install Python 3.11

1. Download from <https://www.python.org/downloads/release/python-3119/>
2. During install, **check "Add Python to PATH"**
3. Open **PowerShell** and verify:

```powershell
python --version
# Should show: Python 3.11.9

pip --version
```

---

### Step 2 — Install Tesseract OCR (optional – for scanned PDFs)

1. Download the installer from <https://github.com/UB-Mannheim/tesseract/wiki>
2. Install to the default path `C:\Program Files\Tesseract-OCR`
3. Add to system PATH — run in **Administrator PowerShell**:

```powershell
[System.Environment]::SetEnvironmentVariable(
    "Path",
    $env:Path + ";C:\Program Files\Tesseract-OCR",
    [System.EnvironmentVariableTarget]::Machine
)
```

4. Close and reopen PowerShell, then verify:

```powershell
tesseract --version
```

> **Skip this step** if you don't need OCR — just set `USE_OCR = False` in `config.py`.

---

### Step 3 — Get the code onto the VM

**Option A — Git clone:**
```powershell
git clone <your-repo-url> C:\pdf-knowledge-bot
cd C:\pdf-knowledge-bot
```

**Option B — Copy files manually** into `C:\pdf-knowledge-bot`, then:
```powershell
cd C:\pdf-knowledge-bot
```

---

### Step 4 — Create a virtual environment

```powershell
python -m venv venv
venv\Scripts\activate
```

You should see `(venv)` at the start of your prompt.

---

### Step 5 — Install dependencies

```powershell
# Install CPU-only PyTorch first (saves ~1.5 GB vs GPU build)
pip install torch --index-url https://download.pytorch.org/whl/cpu

# Install all remaining dependencies
pip install -r requirements.txt
```

> ⏱ First run will also download the **Nomic Embed v1.5** model (~550 MB). This happens automatically when the RAG service starts.

---

### Step 6 — Configure

Open `config.py` in any editor and set these three values:

```python
LLM_MODEL    = "llama-3.3-70b"                # your model name
LLM_API_KEY  = "sk-your-actual-api-key-here"   # your API key
LLM_BASE_URL = "https://api.openai.com/v1"     # your provider URL
```

**Provider URL examples:**

| Provider | `LLM_BASE_URL` |
|---|---|
| OpenAI | `https://api.openai.com/v1` |
| OpenRouter | `https://openrouter.ai/api/v1` |
| Together AI | `https://api.together.xyz/v1` |
| Groq | `https://api.groq.com/openai/v1` |

---

### Step 7 — Start all services

You have **two options**:

#### Option A — One command (recommended)

```powershell
python start_services.py
```

This launches all 4 processes and shows you the status. Press `Ctrl+C` to stop everything.

#### Option B — Four separate PowerShell windows

Open **4 PowerShell windows**, activate venv in each, then:

**Window 1 — Text Extraction Service:**
```powershell
cd C:\pdf-knowledge-bot
venv\Scripts\activate
python text_extraction_api.py
```
Wait until you see: `Uvicorn running on http://0.0.0.0:8001`

**Window 2 — RAG Service (takes ~1 min first time — loads embedding model):**
```powershell
cd C:\pdf-knowledge-bot
venv\Scripts\activate
python rag_api.py
```
Wait until you see: `Uvicorn running on http://0.0.0.0:8002`
> ⚠️ **First time:** this downloads the Nomic Embed model (~550 MB). Wait for `Embedding model loaded.` before proceeding.

**Window 3 — Chat Orchestrator:**
```powershell
cd C:\pdf-knowledge-bot
venv\Scripts\activate
python chat_api.py
```
Wait until you see: `Uvicorn running on http://0.0.0.0:8003`

**Window 4 — Streamlit UI:**
```powershell
cd C:\pdf-knowledge-bot
venv\Scripts\activate
streamlit run app.py
```

---

### Step 8 — Use the app

1. Open **http://localhost:8501** in your browser
2. Click **🔄 Check Services** in the sidebar — all 3 should show ✅
3. Click **Initialize Bot**
4. Go to the **📄 Upload & Process** tab
5. Upload one or more PDF files
6. Click **🚀 Process PDFs** — wait for it to finish
7. Switch to the **💬 Ask Questions** tab
8. Type a question and click **🔍 Ask**

---

### Step 9 — Verify APIs are working (optional)

Each service has **Swagger docs** you can open in your browser:

| Service | Swagger URL |
|---|---|
| Text Extraction | http://localhost:8001/docs |
| RAG Service | http://localhost:8002/docs |
| Chat Orchestrator | http://localhost:8003/docs |

You can also check health manually:

```powershell
curl http://localhost:8001/health
curl http://localhost:8002/health
curl http://localhost:8003/health
```

---

### Stopping the services

- **If using `start_services.py`:** Press `Ctrl+C` — it stops everything.
- **If using separate windows:** Press `Ctrl+C` in each window.

---

## 🐳 Running WITH Docker (Windows 11 VM)

### Step 1 — Install Docker Desktop

1. Download from <https://www.docker.com/products/docker-desktop/>
2. Install and **restart** your machine
3. Open Docker Desktop and wait until the engine is running
4. Open PowerShell and verify:

```powershell
docker --version
docker compose version
```

---

### Step 2 — Configure

Edit `config.py` — set `LLM_MODEL`, `LLM_API_KEY`, `LLM_BASE_URL` (same as Step 6 above).

---

### Step 3 — Build all services

```powershell
cd C:\pdf-knowledge-bot

# Build all 4 images (first time takes 5–10 min)
docker compose build
```

---

### Step 4 — Start all services

```powershell
docker compose up -d
```

Docker starts the services in the correct order:
1. `text-extraction` (Port 8001) — starts first
2. `rag-service` (Port 8002) — starts first, waits for model load
3. `chat-orchestrator` (Port 8003) — starts after 1 + 2 are healthy
4. `ui` (Port 8501) — starts after 3 is healthy

> ⏱ **First launch:** the RAG service downloads the Nomic Embed model (~550 MB). This can take 2–5 minutes. Watch progress with `docker compose logs -f rag-service`.

---

### Step 5 — Open the app

Open **http://localhost:8501** in your browser.

1. Click **🔄 Check Services** — wait for all 3 to show ✅
2. Click **Initialize Bot**
3. Upload PDFs → Process → Ask questions

---

### Useful Docker commands

```powershell
# See logs for all services (live)
docker compose logs -f

# See logs for one specific service
docker compose logs -f rag-service
docker compose logs -f text-extraction
docker compose logs -f chat-orchestrator
docker compose logs -f ui

# Check status of all containers
docker compose ps

# Stop all services
docker compose down

# Rebuild after code changes
docker compose build --no-cache
docker compose up -d

# Restart one service without rebuilding
docker compose restart rag-service

# Shell into a container
docker compose exec rag-service bash
```

---

### Docker volume mapping

| Host path | Container path | Purpose |
|---|---|---|
| `./indices/` | `/app/indices/` | Saved FAISS / TF-IDF / KG indices (persisted across restarts) |
| `./uploaded_pdfs/` | `/app/uploaded_pdfs/` | Uploaded PDF files |
| `./extracted_images/` | `/app/extracted_images/` | Images extracted from PDF pages |
| `./config.py` | `/app/config.py` | Config file (edit without rebuild) |

---

## 🧪 Using the APIs directly (no Streamlit)

You can call the APIs programmatically with `curl` or any HTTP client:

### Process a PDF

```powershell
curl -X POST http://localhost:8003/process `
  -F "files=@C:\docs\manual.pdf" `
  -F "use_ocr=true" `
  -F "use_kg=true"
```

### Ask a question

```powershell
curl -X POST http://localhost:8003/ask `
  -H "Content-Type: application/json" `
  -d '{"question": "What is the BATCH ID?", "top_k": 5}'
```

### Python example

```python
import requests

# Process PDF
with open(r"C:\docs\manual.pdf", "rb") as f:
    resp = requests.post(
        "http://localhost:8003/process",
        files={"files": ("manual.pdf", f, "application/pdf")},
        data={"use_ocr": "true", "use_kg": "true"},
    )
    print(resp.json())

# Ask question
resp = requests.post(
    "http://localhost:8003/ask",
    json={"question": "What is the BATCH ID?", "top_k": 5},
)
print(resp.json()["answer"])
```

---

## ⚙️ Configuration Reference (`config.py`)

| Setting | Default | Description |
|---|---|---|
| `LLM_MODEL` | `"llama-3.3-70b"` | Model name sent to the API |
| `LLM_API_KEY` | `"your-api-key-here"` | Your API key |
| `LLM_BASE_URL` | `"https://api.openai.com/v1"` | Provider endpoint |
| `MAX_TOKENS` | `2000` | Max response tokens |
| `TEMPERATURE` | `0` | 0 = deterministic |
| `EMBEDDING_MODEL` | `"nomic-ai/nomic-embed-text-v1.5"` | Embedding model |
| `MATRYOSHKA_DIM` | `768` | Dimension (768/512/256/128) |
| `CHUNK_SIZE` | `800` | Words per chunk |
| `CHUNK_OVERLAP` | `150` | Overlapping words |
| `DEFAULT_TOP_K` | `5` | Chunks to retrieve |
| `SEMANTIC_WEIGHT` | `0.6` | Semantic search weight |
| `KEYWORD_WEIGHT` | `0.4` | TF-IDF search weight |
| `USE_OCR` | `True` | OCR for scanned pages |
| `USE_KNOWLEDGE_GRAPH` | `True` | Build entity graph |
| `TEXT_EXTRACTION_URL` | `http://localhost:8001` | Text Extraction API address |
| `RAG_SERVICE_URL` | `http://localhost:8002` | RAG Service API address |
| `CHAT_API_URL` | `http://localhost:8003` | Chat Orchestrator API address |

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `tesseract is not installed` | Install Tesseract and add to PATH, or set `USE_OCR = False` |
| `torch` install fails | Use `pip install torch --index-url https://download.pytorch.org/whl/cpu` |
| Out of memory on large PDFs | Reduce `BATCH_SIZE` in config.py (e.g. 8 or 16) |
| Slow first run | Normal — Nomic model downloads once (~550 MB) |
| `trust_remote_code` warning | Expected with Nomic v1.5 — safe to accept |
| Port already in use | Kill the process on that port or change the port in the respective `_api.py` file |
| Docker build slow | First build downloads PyTorch + model; subsequent builds use cache |
| Service shows ❌ in sidebar | That service is not running — check its terminal/logs for errors |
| `Connection refused` errors | Make sure all 3 API services are running before opening Streamlit |
| RAG service takes long to start | Normal on first run — it downloads the 550 MB embedding model |

---

## Project Structure

```
pdf-knowledge-bot/
├── config.py                      # All configuration
├── text_extraction_service.py     # Layer 1: PDF → text → chunks + images
├── rag_service.py                 # Layer 2: Embeddings + FAISS + KG
├── chat_orchestrator.py           # Layer 3: LLM + orchestration
├── app.py                         # Streamlit web UI
├── requirements.txt               # Python dependencies (3.11.9)
├── Dockerfile                     # Container build (Python 3.11)
├── docker-compose.yml             # Container orchestration
├── README.md                      # This file
├── indices/                       # Saved indices (auto-created)
├── uploaded_pdfs/                 # Uploaded files (auto-created)
└── extracted_images/              # Images from PDF pages (auto-created)
```
