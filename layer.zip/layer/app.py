"""
Streamlit UI for PDF Knowledge Bot – Microservice Edition
==========================================================
LEFT  = Chat Q&A (questions, answers, source images)
RIGHT = PDF Viewer (click a source page number → opens that page)

Calls three backend APIs:
    Port 8001 – Text Extraction Service
    Port 8002 – RAG Service
    Port 8003 – Chat Orchestrator (main entry point)

Run:  streamlit run app.py
"""

import streamlit as st
import os
import time
import base64
import requests
from typing import Dict
from pathlib import Path

import fitz  # PyMuPDF – only used for PDF rendering in the viewer

import config

# ──────────────────────────────────────────────
# API URLs (env vars override config for Docker)
# ──────────────────────────────────────────────
CHAT_API_URL = os.environ.get(
    "CHAT_API_URL",
    getattr(config, "CHAT_API_URL", "http://localhost:8003"),
)
RAG_API_URL = os.environ.get(
    "RAG_SERVICE_URL",
    getattr(config, "RAG_SERVICE_URL", "http://localhost:8002"),
)
REQUEST_TIMEOUT = 600  # seconds

# ──────────────────────────────────────────────
# Page config & CSS
# ──────────────────────────────────────────────
st.set_page_config(
    page_title="PDF Knowledge Bot",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .main-header {font-size:2.2rem;color:#1E88E5;text-align:center;margin-bottom:.5rem}
    .source-box {background:#f0f2f6;padding:.8rem;border-radius:.5rem;margin:.3rem 0}
    .confidence-high {color:#4CAF50;font-weight:bold}
    .confidence-medium {color:#FF9800;font-weight:bold}
    .confidence-low {color:#F44336;font-weight:bold}
    .pdf-viewer-container {border:2px solid #e0e0e0;border-radius:8px;padding:10px;
        background:#fafafa;max-height:80vh;overflow-y:auto}
    .answer-container {background:#f8f9fa;padding:1.2rem;border-radius:8px;
        border-left:4px solid #1E88E5;margin:.8rem 0}
    .ref-image-container {display:inline-block;margin:4px;border:1px solid #ccc;
        border-radius:4px;padding:2px}
    .svc-ok {color:#4CAF50;font-weight:bold}
    .svc-down {color:#F44336;font-weight:bold}
</style>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────
# Session state defaults
# ──────────────────────────────────────────────
_defaults = {
    "initialized": False,
    "indexed": False,
    "chat_history": [],
    "current_pdf_path": None,
    "current_page": 1,
    "uploaded_pdf_paths": {},
}
for k, v in _defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ══════════════════════════════════════════════
#  Helper functions
# ══════════════════════════════════════════════
def check_services() -> Dict:
    """Check health of all backend services."""
    result = {}
    for name, url in [
        ("Text Extraction", "http://localhost:8001"),
        ("RAG Service", "http://localhost:8002"),
        ("Chat Orchestrator", "http://localhost:8003"),
    ]:
        try:
            r = requests.get(f"{url}/health", timeout=5)
            result[name] = r.json() if r.status_code == 200 else {"status": "error"}
        except Exception:
            result[name] = {"status": "unreachable"}
    return result


def render_pdf_page(pdf_path: str, page_number: int) -> str | None:
    """Render a PDF page to a base64 PNG data-URI."""
    try:
        doc = fitz.open(pdf_path)
        if page_number < 1 or page_number > len(doc):
            return None
        pix = doc[page_number - 1].get_pixmap(matrix=fitz.Matrix(2, 2))
        b64 = base64.b64encode(pix.tobytes("png")).decode()
        doc.close()
        return f"data:image/png;base64,{b64}"
    except Exception as e:
        st.error(f"Error rendering PDF page: {e}")
        return None


def display_pdf_viewer(pdf_path: str | None, page_number: int):
    """Show a navigable PDF page viewer."""
    if not pdf_path or not os.path.exists(pdf_path):
        st.info("📄 No PDF selected. Click a source page number in the chat to view it here.")
        return

    try:
        doc = fitz.open(pdf_path)
        total = len(doc)
        doc.close()
    except Exception as e:
        st.error(f"Error opening PDF: {e}")
        return

    st.markdown(f"**📄 {os.path.basename(pdf_path)}** — Page **{page_number}** / {total}")

    c1, c2, c3 = st.columns([1, 2, 1])
    with c1:
        if st.button("⬅️ Prev", disabled=(page_number <= 1), key="pdf_prev"):
            st.session_state.current_page = max(1, page_number - 1)
            st.rerun()
    with c2:
        new = st.number_input("Go to", 1, total, page_number, key="page_input")
        if new != page_number:
            st.session_state.current_page = new
            st.rerun()
    with c3:
        if st.button("Next ➡️", disabled=(page_number >= total), key="pdf_next"):
            st.session_state.current_page = min(total, page_number + 1)
            st.rerun()

    img = render_pdf_page(pdf_path, page_number)
    if img:
        st.markdown(
            f'<div class="pdf-viewer-container">'
            f'<img src="{img}" style="width:100%;height:auto;">'
            f'</div>',
            unsafe_allow_html=True,
        )
    else:
        st.error("Failed to render PDF page")


def process_pdfs_via_api(pdf_files, use_kg: bool, use_ocr: bool):
    """Send uploaded PDFs to the Chat Orchestrator /process endpoint."""
    files_data = []
    for f in pdf_files:
        files_data.append(("files", (f.name, f.getbuffer(), "application/pdf")))

    with st.spinner(f"Processing {len(pdf_files)} PDF(s) via microservices …"):
        t0 = time.time()
        resp = requests.post(
            f"{CHAT_API_URL}/process",
            files=files_data,
            data={
                "use_ocr": str(use_ocr).lower(),
                "use_kg": str(use_kg).lower(),
                "chunk_size": str(config.CHUNK_SIZE),
                "overlap": str(config.CHUNK_OVERLAP),
            },
            timeout=REQUEST_TIMEOUT,
        )
        elapsed = time.time() - t0

    if resp.status_code != 200:
        raise Exception(f"Processing failed: {resp.text}")

    result = resp.json()
    return result["total_chunks"], elapsed


def ask_question_via_api(
    question: str, top_k: int, use_hybrid: bool, use_kg: bool
) -> dict:
    """Send question to the Chat Orchestrator /ask endpoint."""
    resp = requests.post(
        f"{CHAT_API_URL}/ask",
        json={
            "question": question,
            "top_k": top_k,
            "use_hybrid": use_hybrid,
            "use_kg": use_kg,
        },
        timeout=REQUEST_TIMEOUT,
    )
    if resp.status_code != 200:
        raise Exception(f"Ask failed: {resp.text}")
    return resp.json()


def load_indices_via_api():
    """Tell backend to load saved indices."""
    resp = requests.post(f"{CHAT_API_URL}/load_indices", timeout=60)
    if resp.status_code != 200:
        raise Exception(f"Load failed: {resp.text}")
    return resp.json()


def get_stats_via_api() -> dict:
    """Fetch stats from the chat orchestrator."""
    try:
        resp = requests.get(f"{CHAT_API_URL}/stats", timeout=10)
        return resp.json() if resp.status_code == 200 else {}
    except Exception:
        return {}


def confidence_html(val: float) -> str:
    if val >= 0.7:
        return f'<span class="confidence-high">High ({val:.2%})</span>'
    if val >= 0.4:
        return f'<span class="confidence-medium">Medium ({val:.2%})</span>'
    return f'<span class="confidence-low">Low ({val:.2%})</span>'


# ══════════════════════════════════════════════
#  Main UI
# ══════════════════════════════════════════════
def main():
    st.markdown('<h1 class="main-header">📚 PDF Knowledge Bot</h1>', unsafe_allow_html=True)

    # ── Sidebar ──────────────────────────────
    with st.sidebar:
        st.header("⚙️ Configuration")

        st.markdown("**🤖 Model Configuration (config.py)**")
        st.info(f"Model: `{config.LLM_MODEL}`")
        st.info(f"API URL: `{config.LLM_BASE_URL}`")
        st.info(f"Embeddings: `{config.EMBEDDING_MODEL}`")

        st.divider()

        # Service health check
        st.header("🔌 Service Status")
        if st.button("🔄 Check Services"):
            svc = check_services()
            for name, info in svc.items():
                status = info.get("status", "unknown")
                if status == "ok":
                    st.markdown(f'<span class="svc-ok">✅ {name}</span>', unsafe_allow_html=True)
                else:
                    st.markdown(f'<span class="svc-down">❌ {name} ({status})</span>', unsafe_allow_html=True)

        st.divider()

        # Initialize (check if backend is ready)
        if not st.session_state.initialized:
            if st.button("Initialize Bot", type="primary"):
                try:
                    svc = check_services()
                    all_ok = all(
                        s.get("status") == "ok" for s in svc.values()
                    )
                    if all_ok:
                        st.session_state.initialized = True
                        st.success("✅ All services are running!")
                    else:
                        down = [n for n, s in svc.items() if s.get("status") != "ok"]
                        st.error(f"Services not ready: {', '.join(down)}")
                except Exception as e:
                    st.error(f"Cannot connect to backend services: {e}")
        else:
            st.success("✅ Bot connected to services")

        # Load saved indices
        if st.session_state.initialized and not st.session_state.indexed:
            if st.button("Load Existing Indices"):
                with st.spinner("Loading …"):
                    try:
                        load_indices_via_api()
                        st.session_state.indexed = True
                        st.success("✅ Indices loaded!")
                    except Exception as e:
                        st.warning(f"No saved indices or load failed: {e}")

        st.divider()

        # Retrieval settings
        st.header("🎛️ Retrieval Settings")
        use_hybrid = st.checkbox("Hybrid Search", True, help="Semantic + keyword")
        use_kg = st.checkbox("Knowledge Graph", True, help="Entity-relation boost")
        top_k = st.slider("Results to retrieve", 1, 10, config.DEFAULT_TOP_K)

        st.divider()

        # Stats
        if st.session_state.indexed:
            st.header("📊 Statistics")
            stats = get_stats_via_api()
            rag_stats = stats.get("rag", {})
            st.metric("Total Chunks", rag_stats.get("num_chunks", 0))
            st.metric("Processed PDFs", stats.get("processed_pdfs", 0))
            if rag_stats.get("kg_nodes", 0) > 0:
                st.metric("KG Nodes", rag_stats["kg_nodes"])
                st.metric("KG Edges", rag_stats["kg_edges"])

    # ── Guard ────────────────────────────────
    if not st.session_state.initialized:
        st.info("👈 Initialize the bot from the sidebar first. Make sure all 3 API services are running.")
        st.markdown("""
        **Start the services:**
        ```bash
        python text_extraction_api.py   # Port 8001
        python rag_api.py               # Port 8002
        python chat_api.py              # Port 8003
        streamlit run app.py            # Port 8501
        ```
        Or use: `python start_services.py`
        """)
        return

    # ── Tabs ─────────────────────────────────
    tab_upload, tab_qa = st.tabs(["📄 Upload & Process", "💬 Ask Questions"])

    # ── Tab 1 – Upload ───────────────────────
    with tab_upload:
        st.header("Upload PDF Documents")
        c1, c2 = st.columns([2, 1])
        with c1:
            files = st.file_uploader(
                "Choose PDF files",
                type=["pdf"],
                accept_multiple_files=True,
                help="Upload one or more PDFs (1 000+ pages supported)",
            )
        with c2:
            st.write("**Processing Options:**")
            enable_ocr = st.checkbox("Enable OCR", True)
            enable_kg = st.checkbox("Build Knowledge Graph", True)

        if files:
            st.write(f"**Selected:** {len(files)} PDF(s)")
            for f in files:
                st.write(f"- {f.name} ({f.size / 1024 / 1024:.2f} MB)")

            if st.button("🚀 Process PDFs", type="primary"):
                try:
                    n, t = process_pdfs_via_api(files, enable_kg, enable_ocr)
                    st.session_state.indexed = True
                    st.success(
                        f"✅ Done — **{n}** chunks in **{t:.1f}s** "
                        f"({t / len(files):.1f}s / file)"
                    )
                except Exception as e:
                    st.error(f"Error: {e}")
                    import traceback
                    st.code(traceback.format_exc())

    # ══════════════════════════════════════════
    #  Tab 2 – Q&A   LEFT = Chat   |   RIGHT = PDF Viewer
    # ══════════════════════════════════════════
    with tab_qa:
        if not st.session_state.indexed:
            st.warning("⚠️ Upload & process PDFs first, or load existing indices.")
            return

        col_chat, col_pdf = st.columns([1, 1], gap="medium")

        # ─── LEFT column: Chat Q&A ───────────
        with col_chat:
            st.markdown("### 💬 Ask Questions")

            with st.expander("💡 Example Questions", expanded=False):
                for eq in [
                    "What is the BATCH ID?",
                    "What are the default values for action codes?",
                    "How do I delete FAN dealer group information?",
                    "What does pressing PF4 do?",
                    "What is the routing number field used for?",
                ]:
                    if st.button(eq, key=f"ex_{eq}"):
                        st.session_state.current_question = eq

            question = st.text_area(
                "Your question:",
                value=st.session_state.get("current_question", ""),
                height=80,
                placeholder="Type your question here…",
            )

            b1, b2 = st.columns(2)
            with b1:
                ask = st.button("🔍 Ask", type="primary", use_container_width=True)
            with b2:
                if st.button("🗑️ Clear History", use_container_width=True):
                    st.session_state.chat_history = []
                    st.rerun()

            if ask and question:
                with st.spinner("Searching …"):
                    try:
                        result = ask_question_via_api(
                            question, top_k, use_hybrid, use_kg,
                        )

                        # Auto-navigate PDF viewer
                        if result.get("pdf_path") and result.get("page_number"):
                            st.session_state.current_pdf_path = result["pdf_path"]
                            st.session_state.current_page = result["page_number"]

                        st.session_state.chat_history.append({
                            "question": question,
                            "answer": result["answer"],
                            "sources": result.get("sources", []),
                            "images": result.get("images", []),
                            "confidence": result.get("confidence", 0),
                        })
                        st.rerun()

                    except Exception as e:
                        st.error(f"Error: {e}")
                        import traceback
                        st.code(traceback.format_exc())

            # ── Chat history ──────────────────
            st.divider()
            st.markdown("### 📜 Chat History")

            for i, chat in enumerate(reversed(st.session_state.chat_history)):
                num = len(st.session_state.chat_history) - i
                with st.container():
                    st.markdown(f"**❓ Question {num}**")
                    st.write(chat["question"])

                    st.markdown('<div class="answer-container">', unsafe_allow_html=True)
                    st.markdown("**💡 Answer:**")
                    st.write(chat["answer"])
                    st.markdown(
                        f"**Confidence:** {confidence_html(chat['confidence'])}",
                        unsafe_allow_html=True,
                    )
                    st.markdown("</div>", unsafe_allow_html=True)

                    # Reference images
                    images = chat.get("images", [])
                    if images:
                        st.markdown("**🖼️ Reference Images from Source Pages:**")
                        img_cols = st.columns(min(len(images), 3))
                        for idx, img_info in enumerate(images):
                            col_idx = idx % min(len(images), 3)
                            with img_cols[col_idx]:
                                try:
                                    st.image(
                                        img_info["path"],
                                        caption=f'{img_info["source"]} — Page {img_info["page"]}',
                                        use_container_width=True,
                                    )
                                except Exception:
                                    st.write(f"⚠️ Could not load image from page {img_info['page']}")

                    # Sources
                    st.markdown("**📚 Sources** (click page to view on the right →):")
                    for j, src in enumerate(chat.get("sources", [])):
                        sc1, sc2 = st.columns([4, 1])
                        with sc1:
                            st.write(
                                f"{src['source']} — Relevance: {src['relevance_score']:.3f}"
                            )
                        with sc2:
                            ppath = src.get("pdf_path")
                            pnum = src["page"]
                            if ppath and os.path.exists(ppath):
                                if st.button(f"📄 Page {pnum}", key=f"pg_{i}_{j}"):
                                    st.session_state.current_pdf_path = ppath
                                    st.session_state.current_page = pnum
                                    st.rerun()
                            else:
                                st.write(f"Page {pnum}")
                    st.divider()

        # ─── RIGHT column: PDF Viewer ────────
        with col_pdf:
            st.markdown("### 📄 PDF Viewer")
            display_pdf_viewer(
                st.session_state.current_pdf_path,
                st.session_state.current_page,
            )


if __name__ == "__main__":
    main()
