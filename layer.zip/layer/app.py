"""
Streamlit UI for PDF Knowledge Bot – Split-Screen Layout
==========================================================
LEFT  = Chat Q&A (questions, answers, source images)
RIGHT = PDF Viewer (click a source page number → opens that page)

Uses the 3-layer architecture:
    Layer 1 – text_extraction_service.py
    Layer 2 – rag_service.py
    Layer 3 – chat_orchestrator.py

Run:  streamlit run app.py
"""

import streamlit as st
import os
import time
import base64
from pathlib import Path

import fitz  # PyMuPDF – render PDF pages

import config
from chat_orchestrator import ChatOrchestrator

# ──────────────────────────────────────────────
# Page config & CSS
# ──────────────────────────────────────────────
st.set_page_config(
    page_title="PDF Knowledge Bot",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .main-header {font-size:2.2rem;color:#1E88E5;text-align:center;margin-bottom:.5rem}
    .source-box {background:#f0f2f6;padding:.8rem;border-radius:.5rem;margin:.3rem 0}
    .confidence-high {color:#4CAF50;font-weight:bold}
    .confidence-medium {color:#FF9800;font-weight:bold}
    .confidence-low {color:#F44336;font-weight:bold}
    .pdf-viewer-container {border:2px solid #e0e0e0;border-radius:8px;padding:10px;
        background:#fafafa;max-height:80vh;overflow-y:auto}
    .answer-container {background:#f8f9fa;padding:1.2rem;border-radius:8px;
        border-left:4px solid #1E88E5;margin:.8rem 0}
    .ref-image-container {display:inline-block;margin:4px;border:1px solid #ccc;
        border-radius:4px;padding:2px}
</style>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────
# Session state defaults
# ──────────────────────────────────────────────
_defaults = {
    "bot": None,
    "indexed": False,
    "chat_history": [],
    "current_pdf_path": None,
    "current_page": 1,
    "uploaded_pdf_paths": {},
}
for k, v in _defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ══════════════════════════════════════════════
#  Helper functions
# ══════════════════════════════════════════════
def initialize_bot():
    """Create a ChatOrchestrator using config.py credentials."""
    api_key = config.LLM_API_KEY if config.LLM_API_KEY != "your-api-key-here" else None
    api_key = api_key or st.session_state.get("api_key")

    if not api_key:
        st.error("Please set **LLM_API_KEY** in config.py!")
        return None

    try:
        return ChatOrchestrator(
            llm_api_key=api_key,
            llm_base_url=config.LLM_BASE_URL,
        )
    except Exception as e:
        st.error(f"Failed to initialize bot: {e}")
        return None


def render_pdf_page(pdf_path: str, page_number: int) -> str | None:
    """Render a PDF page to a base64 PNG data-URI."""
    try:
        doc = fitz.open(pdf_path)
        if page_number < 1 or page_number > len(doc):
            return None
        pix = doc[page_number - 1].get_pixmap(matrix=fitz.Matrix(2, 2))
        b64 = base64.b64encode(pix.tobytes("png")).decode()
        doc.close()
        return f"data:image/png;base64,{b64}"
    except Exception as e:
        st.error(f"Error rendering PDF page: {e}")
        return None


def display_pdf_viewer(pdf_path: str | None, page_number: int):
    """Show a navigable PDF page viewer."""
    if not pdf_path or not os.path.exists(pdf_path):
        st.info("📄 No PDF selected. Click a source page number in the chat to view it here.")
        return

    try:
        doc = fitz.open(pdf_path)
        total = len(doc)
        doc.close()
    except Exception as e:
        st.error(f"Error opening PDF: {e}")
        return

    st.markdown(f"**📄 {os.path.basename(pdf_path)}** — Page **{page_number}** / {total}")

    c1, c2, c3 = st.columns([1, 2, 1])
    with c1:
        if st.button("⬅️ Prev", disabled=(page_number <= 1), key="pdf_prev"):
            st.session_state.current_page = max(1, page_number - 1)
            st.rerun()
    with c2:
        new = st.number_input("Go to", 1, total, page_number, key="page_input")
        if new != page_number:
            st.session_state.current_page = new
            st.rerun()
    with c3:
        if st.button("Next ➡️", disabled=(page_number >= total), key="pdf_next"):
            st.session_state.current_page = min(total, page_number + 1)
            st.rerun()

    img = render_pdf_page(pdf_path, page_number)
    if img:
        st.markdown(
            f'<div class="pdf-viewer-container">'
            f'<img src="{img}" style="width:100%;height:auto;">'
            f'</div>',
            unsafe_allow_html=True,
        )
    else:
        st.error("Failed to render PDF page")


def process_pdfs(pdf_files, use_kg: bool, use_ocr: bool):
    """Save uploads and run the processing pipeline."""
    pdf_dir = Path(config.UPLOADED_PDFS_DIR)
    pdf_dir.mkdir(exist_ok=True)

    paths: list[str] = []
    for f in pdf_files:
        p = pdf_dir / f.name
        p.write_bytes(f.getbuffer())
        paths.append(str(p))
        st.session_state.uploaded_pdf_paths[f.name] = str(p)

    with st.spinner(f"Processing {len(pdf_files)} PDF(s) … this may take a while."):
        st.session_state.bot.pdf_processor.use_ocr = use_ocr
        t0 = time.time()
        n = st.session_state.bot.process_pdfs(paths, use_kg=use_kg)
        elapsed = time.time() - t0

    st.session_state.bot.save_indices()
    return n, elapsed


def confidence_html(val: float) -> str:
    if val >= 0.7:
        return f'<span class="confidence-high">High ({val:.2%})</span>'
    if val >= 0.4:
        return f'<span class="confidence-medium">Medium ({val:.2%})</span>'
    return f'<span class="confidence-low">Low ({val:.2%})</span>'


# ══════════════════════════════════════════════
#  Main UI
# ══════════════════════════════════════════════
def main():
    st.markdown('<h1 class="main-header">📚 PDF Knowledge Bot</h1>', unsafe_allow_html=True)

    # ── Sidebar ──────────────────────────────
    with st.sidebar:
        st.header("⚙️ Configuration")

        st.markdown("**🤖 Model Configuration (config.py)**")
        st.info(f"Model: `{config.LLM_MODEL}`")
        st.info(f"API URL: `{config.LLM_BASE_URL}`")
        st.info(f"Embeddings: `{config.EMBEDDING_MODEL}`")

        config_has_key = config.LLM_API_KEY != "your-api-key-here"
        if config_has_key:
            st.success("✅ API Key configured in config.py")
        else:
            st.warning("⚠️ Set LLM_API_KEY in config.py")
            api_key = st.text_input(
                "LLM API Key (temporary)",
                type="password",
                key="api_key",
                help="Set LLM_API_KEY in config.py for permanent use",
            )

        st.divider()

        # Initialize
        if st.session_state.bot is None:
            if st.button("Initialize Bot", type="primary"):
                bot = initialize_bot()
                if bot:
                    st.session_state.bot = bot
                    st.success("✅ Bot initialized!")

        # Load saved indices
        if st.session_state.bot and not st.session_state.indexed:
            idx_file = os.path.join(config.INDICES_DIR, "faiss.index")
            if os.path.exists(idx_file):
                if st.button("Load Existing Indices"):
                    with st.spinner("Loading …"):
                        st.session_state.bot.load_indices()
                        st.session_state.indexed = True
                        st.success("✅ Indices loaded!")

        st.divider()

        # Retrieval settings
        st.header("🎛️ Retrieval Settings")
        use_hybrid = st.checkbox("Hybrid Search", True, help="Semantic + keyword")
        use_kg = st.checkbox("Knowledge Graph", True, help="Entity-relation boost")
        top_k = st.slider("Results to retrieve", 1, 10, config.DEFAULT_TOP_K)

        st.divider()

        # Stats
        if st.session_state.indexed and st.session_state.bot:
            st.header("📊 Statistics")
            st.metric("Total Chunks", len(st.session_state.bot.retriever.chunks))
            st.metric("Processed PDFs", len(st.session_state.bot.processed_pdfs))
            kg = st.session_state.bot.retriever.kg
            if kg.graph.number_of_nodes() > 0:
                st.metric("KG Nodes", kg.graph.number_of_nodes())
                st.metric("KG Edges", kg.graph.number_of_edges())

    # ── Guard ────────────────────────────────
    if st.session_state.bot is None:
        st.info("👈 Initialize the bot from the sidebar first")
        return

    # ── Tabs ─────────────────────────────────
    tab_upload, tab_qa = st.tabs(["📄 Upload & Process", "💬 Ask Questions"])

    # ── Tab 1 – Upload ───────────────────────
    with tab_upload:
        st.header("Upload PDF Documents")
        c1, c2 = st.columns([2, 1])
        with c1:
            files = st.file_uploader(
                "Choose PDF files",
                type=["pdf"],
                accept_multiple_files=True,
                help="Upload one or more PDFs (1 000+ pages supported)",
            )
        with c2:
            st.write("**Processing Options:**")
            enable_ocr = st.checkbox("Enable OCR", True)
            enable_kg = st.checkbox("Build Knowledge Graph", True)

        if files:
            st.write(f"**Selected:** {len(files)} PDF(s)")
            for f in files:
                st.write(f"- {f.name} ({f.size / 1024 / 1024:.2f} MB)")

            if st.button("🚀 Process PDFs", type="primary"):
                try:
                    n, t = process_pdfs(files, enable_kg, enable_ocr)
                    st.session_state.indexed = True
                    st.success(
                        f"✅ Done — **{n}** chunks in **{t:.1f}s** "
                        f"({t / len(files):.1f}s / file)"
                    )
                except Exception as e:
                    st.error(f"Error: {e}")
                    import traceback
                    st.code(traceback.format_exc())

    # ══════════════════════════════════════════
    #  Tab 2 – Q&A   LEFT = Chat   |   RIGHT = PDF Viewer
    # ══════════════════════════════════════════
    with tab_qa:
        if not st.session_state.indexed:
            st.warning("⚠️ Upload & process PDFs first, or load existing indices.")
            return

        col_chat, col_pdf = st.columns([1, 1], gap="medium")

        # ─── LEFT column: Chat Q&A ───────────
        with col_chat:
            st.markdown("### 💬 Ask Questions")

            with st.expander("💡 Example Questions", expanded=False):
                for eq in [
                    "What is the BATCH ID?",
                    "What are the default values for action codes?",
                    "How do I delete FAN dealer group information?",
                    "What does pressing PF4 do?",
                    "What is the routing number field used for?",
                ]:
                    if st.button(eq, key=f"ex_{eq}"):
                        st.session_state.current_question = eq

            question = st.text_area(
                "Your question:",
                value=st.session_state.get("current_question", ""),
                height=80,
                placeholder="Type your question here…",
            )

            b1, b2 = st.columns(2)
            with b1:
                ask = st.button("🔍 Ask", type="primary", use_container_width=True)
            with b2:
                if st.button("🗑️ Clear History", use_container_width=True):
                    st.session_state.chat_history = []
                    st.rerun()

            if ask and question:
                with st.spinner("Searching …"):
                    try:
                        result = st.session_state.bot.ask(
                            question,
                            top_k=top_k,
                            use_hybrid=use_hybrid,
                            use_kg=use_kg,
                        )

                        # Auto-navigate PDF viewer to the primary source page
                        if result.get("pdf_path") and result.get("page_number"):
                            st.session_state.current_pdf_path = result["pdf_path"]
                            st.session_state.current_page = result["page_number"]

                        st.session_state.chat_history.append({
                            "question": question,
                            "answer": result["answer"],
                            "sources": result["sources"],
                            "images": result.get("images", []),
                            "confidence": result["confidence"],
                        })
                        st.rerun()

                    except Exception as e:
                        st.error(f"Error: {e}")
                        import traceback
                        st.code(traceback.format_exc())

            # ── Chat history ──────────────────
            st.divider()
            st.markdown("### 📜 Chat History")

            for i, chat in enumerate(reversed(st.session_state.chat_history)):
                num = len(st.session_state.chat_history) - i
                with st.container():
                    st.markdown(f"**❓ Question {num}**")
                    st.write(chat["question"])

                    st.markdown('<div class="answer-container">', unsafe_allow_html=True)
                    st.markdown("**💡 Answer:**")
                    st.write(chat["answer"])
                    st.markdown(
                        f"**Confidence:** {confidence_html(chat['confidence'])}",
                        unsafe_allow_html=True,
                    )
                    st.markdown("</div>", unsafe_allow_html=True)

                    # ── Reference images from source pages ──
                    images = chat.get("images", [])
                    if images:
                        st.markdown("**🖼️ Reference Images from Source Pages:**")
                        img_cols = st.columns(min(len(images), 3))
                        for idx, img_info in enumerate(images):
                            col_idx = idx % min(len(images), 3)
                            with img_cols[col_idx]:
                                try:
                                    st.image(
                                        img_info["path"],
                                        caption=f'{img_info["source"]} — Page {img_info["page"]}',
                                        use_container_width=True,
                                    )
                                except Exception:
                                    st.write(
                                        f"⚠️ Could not load image from page {img_info['page']}"
                                    )

                    # ── Sources (click page → opens in right-side PDF viewer) ──
                    st.markdown("**📚 Sources** (click page to view on the right →):")
                    for j, src in enumerate(chat["sources"]):
                        sc1, sc2 = st.columns([4, 1])
                        with sc1:
                            st.write(
                                f"{src['source']} — Relevance: {src['relevance_score']:.3f}"
                            )
                        with sc2:
                            ppath = src.get("pdf_path")
                            pnum = src["page"]
                            if ppath and os.path.exists(ppath):
                                if st.button(
                                    f"📄 Page {pnum}",
                                    key=f"pg_{i}_{j}",
                                ):
                                    st.session_state.current_pdf_path = ppath
                                    st.session_state.current_page = pnum
                                    st.rerun()
                            else:
                                st.write(f"Page {pnum}")
                    st.divider()

        # ─── RIGHT column: PDF Viewer ────────
        with col_pdf:
            st.markdown("### 📄 PDF Viewer")
            display_pdf_viewer(
                st.session_state.current_pdf_path,
                st.session_state.current_page,
            )


if __name__ == "__main__":
    main()
