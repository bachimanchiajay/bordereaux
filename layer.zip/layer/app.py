"""
Streamlit UI for PDF Knowledge Bot – Independent Microservice Edition
======================================================================
Designed so that you can run each backend service ONE AT A TIME:

  Step 1:  Start text_extraction_api.py  (port 8001)  →  Upload & extract PDFs
  Step 2:  Start rag_api.py              (port 8002)  →  Index chunks
  Step 3:  Start chat_api.py             (port 8003)  →  Chat / ask questions

The UI calls each service DIRECTLY – it does NOT require all three to be
running at the same time.  Only the service needed for the current step must
be alive.

Run:  streamlit run app.py --server.port 8501
"""

import streamlit as st
import os
import json
import time
import base64
import requests
from typing import Dict
from pathlib import Path

import fitz  # PyMuPDF – only for PDF rendering in the viewer

import config

# ──────────────────────────────────────────────
# Service URLs (env vars override config)
# ──────────────────────────────────────────────
TEXT_EXTRACTION_URL = os.environ.get(
    "TEXT_EXTRACTION_URL",
    getattr(config, "TEXT_EXTRACTION_URL", "http://localhost:8001"),
)
RAG_SERVICE_URL = os.environ.get(
    "RAG_SERVICE_URL",
    getattr(config, "RAG_SERVICE_URL", "http://localhost:8002"),
)
CHAT_API_URL = os.environ.get(
    "CHAT_API_URL",
    getattr(config, "CHAT_API_URL", "http://localhost:8003"),
)
REQUEST_TIMEOUT = 1800  # seconds – large PDFs on CPU

# Local file to persist extracted chunks between steps
CHUNKS_CACHE_FILE = os.path.join(config.INDICES_DIR, "extracted_chunks.json")


# ──────────────────────────────────────────────
# Page config & CSS
# ──────────────────────────────────────────────
st.set_page_config(
    page_title="PDF Knowledge Bot",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .main-header {font-size:2.2rem;color:#1E88E5;text-align:center;margin-bottom:.5rem}
    .source-box {background:#f0f2f6;padding:.8rem;border-radius:.5rem;margin:.3rem 0}
    .confidence-high {color:#4CAF50;font-weight:bold}
    .confidence-medium {color:#FF9800;font-weight:bold}
    .confidence-low {color:#F44336;font-weight:bold}
    .pdf-viewer-container {border:2px solid #e0e0e0;border-radius:8px;padding:10px;
        background:#fafafa;max-height:80vh;overflow-y:auto}
    .answer-container {background:#f8f9fa;padding:1.2rem;border-radius:8px;
        border-left:4px solid #1E88E5;margin:.8rem 0}
    .svc-ok  {color:#4CAF50;font-weight:bold}
    .svc-down{color:#F44336;font-weight:bold}
    .step-ok {background:#e8f5e9;padding:.6rem;border-radius:6px;margin:.4rem 0}
    .step-wait{background:#fff3e0;padding:.6rem;border-radius:6px;margin:.4rem 0}
</style>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────
# Session state defaults
# ──────────────────────────────────────────────
_defaults = {
    "step1_done": False,      # extraction complete
    "step2_done": False,      # indexing complete
    "chat_history": [],
    "current_pdf_path": None,
    "current_page": 1,
    "uploaded_pdf_paths": {},
    "extracted_chunks": [],    # chunks saved after step 1
    "num_chunks": 0,
}
for k, v in _defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ══════════════════════════════════════════════
#  Helper functions
# ══════════════════════════════════════════════
def _is_service_up(url: str) -> bool:
    """Quick health check – returns True/False."""
    try:
        r = requests.get(f"{url}/health", timeout=5)
        return r.status_code == 200 and r.json().get("status") == "ok"
    except Exception:
        return False


def check_services() -> Dict:
    """Check health of all backend services."""
    result = {}
    for name, url in [
        ("Text Extraction (8001)", TEXT_EXTRACTION_URL),
        ("RAG Service (8002)", RAG_SERVICE_URL),
        ("Chat Orchestrator (8003)", CHAT_API_URL),
    ]:
        try:
            r = requests.get(f"{url}/health", timeout=5)
            result[name] = r.json() if r.status_code == 200 else {"status": "error"}
        except Exception:
            result[name] = {"status": "unreachable"}
    return result


def render_pdf_page(pdf_path: str, page_number: int) -> str | None:
    try:
        doc = fitz.open(pdf_path)
        if page_number < 1 or page_number > len(doc):
            return None
        pix = doc[page_number - 1].get_pixmap(matrix=fitz.Matrix(2, 2))
        b64 = base64.b64encode(pix.tobytes("png")).decode()
        doc.close()
        return f"data:image/png;base64,{b64}"
    except Exception as e:
        st.error(f"Error rendering PDF page: {e}")
        return None


def display_pdf_viewer(pdf_path: str | None, page_number: int):
    if not pdf_path or not os.path.exists(pdf_path):
        st.info("📄 No PDF selected. Click a source page number in the chat to view it here.")
        return
    try:
        doc = fitz.open(pdf_path)
        total = len(doc)
        doc.close()
    except Exception as e:
        st.error(f"Error opening PDF: {e}")
        return

    st.markdown(f"**📄 {os.path.basename(pdf_path)}** — Page **{page_number}** / {total}")

    c1, c2, c3 = st.columns([1, 2, 1])
    with c1:
        if st.button("⬅️ Prev", disabled=(page_number <= 1), key="pdf_prev"):
            st.session_state.current_page = max(1, page_number - 1)
            st.rerun()
    with c2:
        new = st.number_input("Go to", 1, total, page_number, key="page_input")
        if new != page_number:
            st.session_state.current_page = new
            st.rerun()
    with c3:
        if st.button("Next ➡️", disabled=(page_number >= total), key="pdf_next"):
            st.session_state.current_page = min(total, page_number + 1)
            st.rerun()

    img = render_pdf_page(pdf_path, page_number)
    if img:
        st.markdown(
            f'<div class="pdf-viewer-container">'
            f'<img src="{img}" style="width:100%;height:auto;">'
            f'</div>',
            unsafe_allow_html=True,
        )
    else:
        st.error("Failed to render PDF page")


def confidence_html(val: float) -> str:
    if val >= 0.7:
        return f'<span class="confidence-high">High ({val:.2%})</span>'
    if val >= 0.4:
        return f'<span class="confidence-medium">Medium ({val:.2%})</span>'
    return f'<span class="confidence-low">Low ({val:.2%})</span>'


def _save_chunks_to_disk(chunks):
    """Persist extracted chunks to disk so they survive app restarts."""
    os.makedirs(config.INDICES_DIR, exist_ok=True)
    with open(CHUNKS_CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(chunks, f)


def _load_chunks_from_disk():
    """Load previously extracted chunks from disk."""
    if os.path.exists(CHUNKS_CACHE_FILE):
        with open(CHUNKS_CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


# ══════════════════════════════════════════════
#  Step 1: Extract PDFs (calls text_extraction_api on 8001 ONLY)
# ══════════════════════════════════════════════
def step1_extract_pdfs(pdf_files, use_ocr: bool):
    """Send PDFs to text_extraction_api → get chunks back. No other service needed."""
    all_chunks = []

    for f in pdf_files:
        file_bytes = f.getbuffer()
        resp = requests.post(
            f"{TEXT_EXTRACTION_URL}/extract_and_chunk",
            files={"file": (f.name, file_bytes, "application/pdf")},
            data={
                "use_ocr": str(use_ocr).lower(),
                "chunk_size": str(config.CHUNK_SIZE),
                "overlap": str(config.CHUNK_OVERLAP),
            },
            timeout=REQUEST_TIMEOUT,
        )
        if resp.status_code != 200:
            raise Exception(f"Extraction failed for {f.name}: {resp.text}")

        result = resp.json()
        all_chunks.extend(result["chunks"])
        st.session_state.uploaded_pdf_paths[f.name] = result.get("pdf_path", "")
        st.write(f"  ✅ {f.name}: {result['num_pages']} pages → {result['num_chunks']} chunks")

    return all_chunks


# ══════════════════════════════════════════════
#  Step 2: Index chunks (calls rag_api on 8002 ONLY)
# ══════════════════════════════════════════════
def step2_index_chunks(chunks, use_kg: bool):
    """Send chunks to rag_api for FAISS + TF-IDF + KG indexing. No other service needed."""
    resp = requests.post(
        f"{RAG_SERVICE_URL}/index",
        json={"chunks": chunks, "use_kg": use_kg},
        timeout=REQUEST_TIMEOUT,
    )
    if resp.status_code != 200:
        raise Exception(f"Indexing failed: {resp.text}")

    index_result = resp.json()

    # Save indices to disk
    requests.post(f"{RAG_SERVICE_URL}/save", timeout=60)

    # Save pdf_paths
    import pickle
    os.makedirs(config.INDICES_DIR, exist_ok=True)
    with open(os.path.join(config.INDICES_DIR, "pdf_paths.pkl"), "wb") as pf:
        pickle.dump(dict(st.session_state.uploaded_pdf_paths), pf)

    return index_result


# ══════════════════════════════════════════════
#  Step 3: Ask questions (calls chat_api on 8003, which calls rag_api on 8002)
# ══════════════════════════════════════════════
def step3_ask_question(question: str, top_k: int, use_hybrid: bool, use_kg: bool) -> dict:
    """Send question to chat_api /ask endpoint."""
    resp = requests.post(
        f"{CHAT_API_URL}/ask",
        json={
            "question": question,
            "top_k": top_k,
            "use_hybrid": use_hybrid,
            "use_kg": use_kg,
        },
        timeout=REQUEST_TIMEOUT,
    )
    if resp.status_code != 200:
        raise Exception(f"Ask failed: {resp.text}")
    return resp.json()


def load_indices_via_rag():
    """Tell RAG service to load saved indices (step 2 shortcut)."""
    resp = requests.post(f"{RAG_SERVICE_URL}/load", timeout=60)
    if resp.status_code != 200:
        raise Exception(f"Load failed: {resp.text}")
    return resp.json()


def load_indices_via_chat():
    """Tell chat_api to load indices (needs both 8002+8003 running)."""
    resp = requests.post(f"{CHAT_API_URL}/load_indices", timeout=60)
    if resp.status_code != 200:
        raise Exception(f"Load failed: {resp.text}")
    return resp.json()


# ══════════════════════════════════════════════
#  Main UI
# ══════════════════════════════════════════════
def main():
    st.markdown('<h1 class="main-header">📚 PDF Knowledge Bot</h1>', unsafe_allow_html=True)

    # ── Sidebar ──────────────────────────────
    with st.sidebar:
        st.header("⚙️ Configuration")

        st.markdown("**🤖 Model Configuration (config.py)**")
        st.info(f"Model: `{config.LLM_MODEL}`")
        st.info(f"Embeddings: `{config.EMBEDDING_MODEL}`")
        st.info(f"Model cache: `{config.MODEL_CACHE_DIR}`")

        st.divider()

        # ── Service health ───────────────────
        st.header("🔌 Service Status")
        if st.button("🔄 Check Services"):
            svc = check_services()
            for name, info in svc.items():
                status = info.get("status", "unknown")
                if status == "ok":
                    st.markdown(f'<span class="svc-ok">✅ {name}</span>', unsafe_allow_html=True)
                else:
                    st.markdown(f'<span class="svc-down">❌ {name} ({status})</span>', unsafe_allow_html=True)

        st.divider()

        # ── Progress tracker ─────────────────
        st.header("📋 Workflow Progress")
        s1 = "✅" if st.session_state.step1_done else "⏳"
        s2 = "✅" if st.session_state.step2_done else "⏳"
        s3 = "💬" if (st.session_state.step2_done) else "⏳"
        st.markdown(f"{s1}  **Step 1:** Extract PDFs (port 8001)")
        st.markdown(f"{s2}  **Step 2:** Index chunks (port 8002)")
        st.markdown(f"{s3}  **Step 3:** Chat / Q&A (port 8003)")

        if st.session_state.num_chunks > 0:
            st.metric("Total Chunks", st.session_state.num_chunks)

        st.divider()

        # ── Retrieval settings ───────────────
        st.header("🎛️ Retrieval Settings")
        use_hybrid = st.checkbox("Hybrid Search", True, help="Semantic + keyword")
        use_kg = st.checkbox("Knowledge Graph", True, help="Entity-relation boost")
        top_k = st.slider("Results to retrieve", 1, 10, config.DEFAULT_TOP_K)

        st.divider()

        # ── Reset ────────────────────────────
        if st.button("🔄 Reset All Steps"):
            for k in list(st.session_state.keys()):
                del st.session_state[k]
            st.rerun()

    # ═════════════════════════════════════════
    #  TABS – three steps, run independently
    # ═════════════════════════════════════════
    tab1, tab2, tab3 = st.tabs([
        "📄 Step 1: Extract PDFs",
        "🧠 Step 2: Index Chunks",
        "💬 Step 3: Chat / Q&A",
    ])

    # ══════════════════════════════════════════
    #  TAB 1 – Extract PDFs  (needs: port 8001 only)
    # ══════════════════════════════════════════
    with tab1:
        st.header("Step 1 — Extract Text from PDFs")
        st.markdown(
            '**Required service:** `python text_extraction_api.py` (port 8001)  \n'
            'Other services do **not** need to be running yet.'
        )

        svc_up = _is_service_up(TEXT_EXTRACTION_URL)
        if svc_up:
            st.success("✅ Text Extraction service is running on port 8001")
        else:
            st.error(
                "❌ Text Extraction service is NOT running.  \n"
                "Start it first: `python text_extraction_api.py`"
            )

        c1, c2 = st.columns([2, 1])
        with c1:
            files = st.file_uploader(
                "Choose PDF files",
                type=["pdf"],
                accept_multiple_files=True,
                help="Upload one or more PDFs",
            )
        with c2:
            st.write("**Options:**")
            enable_ocr = st.checkbox("Enable OCR (for scanned pages)", True)

        if files:
            st.write(f"**Selected:** {len(files)} PDF(s)")
            for f in files:
                st.write(f"  - {f.name} ({f.size / 1024 / 1024:.2f} MB)")

            if st.button("🚀 Extract PDFs", type="primary", disabled=not svc_up):
                with st.spinner(f"Extracting text from {len(files)} PDF(s) … this may take a while"):
                    try:
                        t0 = time.time()
                        chunks = step1_extract_pdfs(files, enable_ocr)
                        elapsed = time.time() - t0

                        # Save chunks to disk for step 2
                        _save_chunks_to_disk(chunks)
                        st.session_state.extracted_chunks = chunks
                        st.session_state.num_chunks = len(chunks)
                        st.session_state.step1_done = True

                        st.success(
                            f"✅ Extraction complete!  \n"
                            f"**{len(chunks)}** chunks from **{len(files)}** PDF(s) "
                            f"in **{elapsed:.1f}s**  \n"
                            f"Chunks saved to disk. You can now stop this service and "
                            f"proceed to **Step 2**."
                        )
                    except Exception as e:
                        st.error(f"Error: {e}")
                        import traceback
                        st.code(traceback.format_exc())

        if st.session_state.step1_done:
            st.markdown(
                '<div class="step-ok">'
                '✅ <b>Step 1 complete.</b> You can now stop text_extraction_api '
                'and start rag_api.py for Step 2.'
                '</div>',
                unsafe_allow_html=True,
            )

    # ══════════════════════════════════════════
    #  TAB 2 – Index chunks  (needs: port 8002 only)
    # ══════════════════════════════════════════
    with tab2:
        st.header("Step 2 — Index Chunks into FAISS + Knowledge Graph")
        st.markdown(
            '**Required service:** `python rag_api.py` (port 8002)  \n'
            'Text Extraction (8001) can be stopped. Chat (8003) is not needed yet.'
        )

        svc_up = _is_service_up(RAG_SERVICE_URL)
        if svc_up:
            st.success("✅ RAG Service is running on port 8002")
        else:
            st.error(
                "❌ RAG Service is NOT running.  \n"
                "Start it first: `python rag_api.py`  \n"
                "(first run will download the embedding model to `./models_cache/`)"
            )

        # Load chunks from disk if not in session
        if not st.session_state.extracted_chunks:
            disk_chunks = _load_chunks_from_disk()
            if disk_chunks:
                st.session_state.extracted_chunks = disk_chunks
                st.session_state.num_chunks = len(disk_chunks)
                st.session_state.step1_done = True

        if st.session_state.extracted_chunks:
            st.info(f"📦 {len(st.session_state.extracted_chunks)} chunks ready for indexing (from Step 1)")
        else:
            st.warning("⚠️ No chunks available. Complete **Step 1** first, or load saved indices below.")

        col1, col2 = st.columns(2)
        with col1:
            enable_kg = st.checkbox("Build Knowledge Graph", True, key="step2_kg")

        with col1:
            if st.button(
                "🧠 Index Chunks Now",
                type="primary",
                disabled=not (svc_up and st.session_state.extracted_chunks),
            ):
                with st.spinner("Indexing chunks (embedding + FAISS + TF-IDF + KG) …"):
                    try:
                        t0 = time.time()
                        result = step2_index_chunks(
                            st.session_state.extracted_chunks, enable_kg
                        )
                        elapsed = time.time() - t0

                        st.session_state.step2_done = True
                        st.success(
                            f"✅ Indexing complete in **{elapsed:.1f}s**!  \n"
                            f"**{result['num_chunks']}** chunks indexed, "
                            f"**{result['faiss_vectors']}** FAISS vectors, "
                            f"**{result.get('kg_nodes', 0)}** KG nodes  \n"
                            f"Indices saved to `{config.INDICES_DIR}/`. "
                            f"You can now proceed to **Step 3**."
                        )
                    except Exception as e:
                        st.error(f"Error: {e}")
                        import traceback
                        st.code(traceback.format_exc())

        with col2:
            if st.button("📂 Load Saved Indices", disabled=not svc_up):
                with st.spinner("Loading saved indices …"):
                    try:
                        result = load_indices_via_rag()
                        st.session_state.step2_done = True
                        st.session_state.num_chunks = result.get("num_chunks", 0)
                        st.success(
                            f"✅ Loaded {result.get('num_chunks', 0)} chunks, "
                            f"{result.get('faiss_vectors', 0)} FAISS vectors"
                        )
                    except Exception as e:
                        st.warning(f"Could not load: {e}")

        if st.session_state.step2_done:
            st.markdown(
                '<div class="step-ok">'
                '✅ <b>Step 2 complete.</b> Keep rag_api.py running and start '
                'chat_api.py for Step 3.'
                '</div>',
                unsafe_allow_html=True,
            )

    # ══════════════════════════════════════════
    #  TAB 3 – Chat / Q&A  (needs: port 8002 + port 8003)
    # ══════════════════════════════════════════
    with tab3:
        st.header("Step 3 — Chat with Your Documents")
        st.markdown(
            '**Required services:**  \n'
            '- `python rag_api.py` (port 8002) — must stay running  \n'
            '- `python chat_api.py` (port 8003)  \n'
            'Text Extraction (8001) is not needed for Q&A.'
        )

        rag_up = _is_service_up(RAG_SERVICE_URL)
        chat_up = _is_service_up(CHAT_API_URL)

        if rag_up and chat_up:
            st.success("✅ RAG Service + Chat Orchestrator are running")
        else:
            if not rag_up:
                st.error("❌ RAG Service (8002) is NOT running. Start it: `python rag_api.py`")
            if not chat_up:
                st.error("❌ Chat Orchestrator (8003) is NOT running. Start it: `python chat_api.py`")

        if not st.session_state.step2_done:
            st.warning("⚠️ Complete **Step 2** first (index chunks), or load saved indices.")

            # Allow loading indices from here too
            if rag_up and st.button("📂 Load Saved Indices (shortcut)", key="tab3_load"):
                with st.spinner("Loading …"):
                    try:
                        result = load_indices_via_rag()
                        st.session_state.step2_done = True
                        st.session_state.num_chunks = result.get("num_chunks", 0)
                        st.success(f"✅ Loaded {result.get('num_chunks', 0)} chunks")
                        st.rerun()
                    except Exception as e:
                        st.warning(f"Could not load: {e}")

        if not (rag_up and chat_up and st.session_state.step2_done):
            return

        # ── Chat layout: LEFT = Q&A, RIGHT = PDF Viewer ──
        col_chat, col_pdf = st.columns([1, 1], gap="medium")

        with col_chat:
            st.markdown("### 💬 Ask Questions")

            with st.expander("💡 Example Questions", expanded=False):
                for eq in [
                    "What is the BATCH ID?",
                    "What are the default values for action codes?",
                    "How do I delete FAN dealer group information?",
                    "What does pressing PF4 do?",
                    "What is the routing number field used for?",
                ]:
                    if st.button(eq, key=f"ex_{eq}"):
                        st.session_state.current_question = eq

            question = st.text_area(
                "Your question:",
                value=st.session_state.get("current_question", ""),
                height=80,
                placeholder="Type your question here…",
            )

            b1, b2 = st.columns(2)
            with b1:
                ask = st.button("🔍 Ask", type="primary", use_container_width=True)
            with b2:
                if st.button("🗑️ Clear History", use_container_width=True):
                    st.session_state.chat_history = []
                    st.rerun()

            if ask and question:
                with st.spinner("Searching …"):
                    try:
                        result = step3_ask_question(question, top_k, use_hybrid, use_kg)

                        if result.get("pdf_path") and result.get("page_number"):
                            st.session_state.current_pdf_path = result["pdf_path"]
                            st.session_state.current_page = result["page_number"]

                        st.session_state.chat_history.append({
                            "question": question,
                            "answer": result["answer"],
                            "sources": result.get("sources", []),
                            "images": result.get("images", []),
                            "confidence": result.get("confidence", 0),
                        })
                        st.rerun()

                    except Exception as e:
                        st.error(f"Error: {e}")
                        import traceback
                        st.code(traceback.format_exc())

            # ── Chat history ──────────────────
            st.divider()
            st.markdown("### 📜 Chat History")

            for i, chat in enumerate(reversed(st.session_state.chat_history)):
                num = len(st.session_state.chat_history) - i
                with st.container():
                    st.markdown(f"**❓ Question {num}**")
                    st.write(chat["question"])

                    st.markdown('<div class="answer-container">', unsafe_allow_html=True)
                    st.markdown("**💡 Answer:**")
                    st.write(chat["answer"])
                    st.markdown(
                        f"**Confidence:** {confidence_html(chat['confidence'])}",
                        unsafe_allow_html=True,
                    )
                    st.markdown("</div>", unsafe_allow_html=True)

                    # Reference images
                    images = chat.get("images", [])
                    if images:
                        st.markdown("**🖼️ Reference Images:**")
                        img_cols = st.columns(min(len(images), 3))
                        for idx, img_info in enumerate(images):
                            col_idx = idx % min(len(images), 3)
                            with img_cols[col_idx]:
                                try:
                                    st.image(
                                        img_info["path"],
                                        caption=f'{img_info["source"]} — Page {img_info["page"]}',
                                        use_container_width=True,
                                    )
                                except Exception:
                                    st.write(f"⚠️ Could not load image from page {img_info['page']}")

                    # Sources
                    st.markdown("**📚 Sources** (click page to view on the right →):")
                    for j, src in enumerate(chat.get("sources", [])):
                        sc1, sc2 = st.columns([4, 1])
                        with sc1:
                            st.write(
                                f"{src['source']} — Relevance: {src['relevance_score']:.3f}"
                            )
                        with sc2:
                            ppath = src.get("pdf_path")
                            pnum = src["page"]
                            if ppath and os.path.exists(ppath):
                                if st.button(f"📄 Page {pnum}", key=f"pg_{i}_{j}"):
                                    st.session_state.current_pdf_path = ppath
                                    st.session_state.current_page = pnum
                                    st.rerun()
                            else:
                                st.write(f"Page {pnum}")
                    st.divider()

        # ─── RIGHT column: PDF Viewer ────────
        with col_pdf:
            st.markdown("### 📄 PDF Viewer")
            display_pdf_viewer(
                st.session_state.current_pdf_path,
                st.session_state.current_page,
            )


if __name__ == "__main__":
    main()
